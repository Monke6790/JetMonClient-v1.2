# JetMonClient (Fabric, Minecraft 26.1.2)

Mod client-side dengan sistem modul dan ClickGUI (kategori + toggle ON/OFF).
Modul:
- **Render**: PlayerESP, Tracer, StorageESP, BlockESP, Nametag, Fullbright
- **Combat** (latihan, hanya aktif di world single-player yang tidak dibuka ke LAN): AutoTotem, AutoCrystal, AnchorMacro, AutoShield, AutoAttack
- **Movement**: AutoSprint
- **Misc**: Coords (HUD), Freecam (kecepatan bisa diatur), Freelook, Zoom (FOV bisa diatur)

ESP/Tracer/StorageESP/BlockESP digambar menembus tembok. Gunakan untuk single-player atau server milik sendiri;
banyak server publik melarangnya. Daftar blok BlockESP bisa diubah di `BlockEsp.java`.

## Membuka GUI
- **PC**: `Right Shift` (bisa diubah di Controls).
- **Android / tanpa keyboard**: buka menu pause, tekan tombol **ClickGUI** di pojok kiri atas.

## Build tanpa PC (GitHub Actions)
1. Push repo ke GitHub (pastikan folder `.github` ikut).
2. Tab **Actions** -> run terbaru -> **Artifacts** -> unduh zip, ambil `jetmonclient-1.0.0.jar`.

## Build lokal
Butuh JDK 25 dan Gradle 9.5+: `gradle build` -> `build/libs/jetmonclient-1.0.0.jar`

## Pasang di launcher Android
1. Install Minecraft **26.1.2** + **Fabric Loader** di launcher (mis. Zalith Launcher 2 / PojavLauncher).
2. Pilih runtime **Java 25**.
3. Taruh **Fabric API 26.1.2** dan `jetmonclient-1.0.0.jar` di folder `mods`.

## Menambah modul
Buat class `extends Module` di `module/impl/`, lalu daftarkan di `ModuleManager`.

## Catatan
26.1 memakai nama resmi Mojang (bukan Yarn): `Minecraft`, `Screen`, `GuiGraphicsExtractor`, `KeyMapping`, dst.

## Setting
Modul yang punya pengaturan menampilkan baris tambahan di bawahnya (mis. `Speed: 10`).
Tap tombol `-` / `+` untuk mengubah nilainya.
- **Freecam**: gerak dengan tombol jalan, lompat = naik, sneak = turun. Speed 1-30 blok/detik.
- **Freelook**: otomatis pindah ke third person, mouse memutar kamera tanpa memutar pemain.
- **Zoom**: FOV minimum di Minecraft adalah 30, jadi itu zoom maksimumnya.

## Membuka setting modul
Klik kanan pada modul (atau tap tombol `>` di barisnya) untuk membuka/menutup setting. Geser slider untuk mengubah nilai (tahan lalu geser kiri/kanan).
Setting tersedia untuk: PlayerESP (Mobs), Tracer (Thickness), StorageESP, BlockESP, AutoShield (jarak), AutoCrystal (delay), Freecam (speed), Zoom (FOV).

## StorageESP & BlockESP
- **Tracers**: toggle di setting StorageESP dan BlockESP (garis ke target terdekat).
- **StorageESP**: toggle per jenis wadah (chest, trapped chest, ender chest, shulker, barrel, hopper, dispenser/dropper).
- **BlockESP**: semua blok bisa dipilih. Buka setting BlockESP -> `Blocks (N)` -> ketik di kolom pencarian, tap blok untuk memilih.
  Tombol `+Shown` menambah semua hasil pencarian, `Clear` mengosongkan pilihan. `Max shown` membatasi jumlah blok terdekat yang digambar.

## Opsi gaya Meteor
- **PlayerESP**: Mobs, Invisible, Distance colors, Fill, Outline, Fill opacity, Outline width.
- **Tracer**: Target (Head/Body/Feet), Invisible, Distance colors, Thickness.
- **StorageESP / BlockESP**: Fill, Outline, Fill opacity, Tracers + Thickness.
- **Nametag**: label di layar (tembus tembok) untuk pemain & mob: Players, Mobs, Health, Distance, Background. Hanya di first person.
- **Freecam**: Disable on damage/death/logout, Render hands, Rotate, Mining, Interact, Speed (scroll mouse juga mengubah Speed).
- Panel modul bisa di-scroll dengan tombol `^` `v` kalau barisnya banyak.

## Gear, keybind, dan penyimpanan
- Tiap modul punya tombol **gear** di samping ON/OFF. Tap gear (atau klik kanan modul) untuk membuka setting.
- Baris **Keybind** paling atas di setting: tap, lalu tekan tombol yang diinginkan. Esc atau tap lagi = hapus. Tombol juga bisa diatur di Options > Controls (kategori JetMonClient).
- Status ON/OFF dan semua setting tersimpan di `config/jetmonclient.json`, jadi tetap sama setelah keluar-masuk server dan membuka ulang game. Freecam dan Freelook sengaja tidak dipulihkan.
