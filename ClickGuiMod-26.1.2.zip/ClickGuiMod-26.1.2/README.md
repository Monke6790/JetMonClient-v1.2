# ClickGUI (Fabric, Minecraft 26.1.2)

Mod client-side dengan sistem modul dan ClickGUI (kategori + toggle ON/OFF).
Modul:
- **Render**: ESP, Tracer, StorageESP, BlockESP, Nametag, Fullbright
- **Combat** (latihan, hanya aktif di world single-player yang tidak dibuka ke LAN): AutoTotem, AutoCrystal, AnchorMacro, AutoShield, AutoAttack
- **Movement**: AutoSprint
- **Misc**: Coords (HUD), Freecam (kecepatan bisa diatur), Freelook, Zoom (FOV bisa diatur)

ESP/Tracer/StorageESP/BlockESP digambar menembus tembok. Gunakan untuk single-player atau server milik sendiri;
banyak server publik melarangnya. Daftar blok BlockESP bisa diubah di `BlockEsp.java`.

## Membuka GUI
- **PC**: `Right Shift` (bisa diubah di Controls).
- **Android / tanpa keyboard**: buka menu pause, tekan tombol **ClickGUI** di pojok kiri atas.

## Build tanpa PC (GitHub Actions)
1. Push repo ke GitHub (pastikan folder `.github` ikut).
2. Tab **Actions** -> run terbaru -> **Artifacts** -> unduh zip, ambil `clickgui-1.0.0.jar`.

## Build lokal
Butuh JDK 25 dan Gradle 9.5+: `gradle build` -> `build/libs/clickgui-1.0.0.jar`

## Pasang di launcher Android
1. Install Minecraft **26.1.2** + **Fabric Loader** di launcher (mis. Zalith Launcher 2 / PojavLauncher).
2. Pilih runtime **Java 25**.
3. Taruh **Fabric API 26.1.2** dan `clickgui-1.0.0.jar` di folder `mods`.

## Menambah modul
Buat class `extends Module` di `module/impl/`, lalu daftarkan di `ModuleManager`.

## Catatan
26.1 memakai nama resmi Mojang (bukan Yarn): `Minecraft`, `Screen`, `GuiGraphicsExtractor`, `KeyMapping`, dst.

## Setting
Modul yang punya pengaturan menampilkan baris tambahan di bawahnya (mis. `Speed: 10`).
Tap tombol `-` / `+` untuk mengubah nilainya.
- **Freecam**: gerak dengan tombol jalan, lompat = naik, sneak = turun. Speed 1-30 blok/detik.
- **Freelook**: otomatis pindah ke third person, mouse memutar kamera tanpa memutar pemain.
- **Zoom**: FOV minimum di Minecraft adalah 30, jadi itu zoom maksimumnya.
