# JetMonClient (Fabric, Minecraft 26.1.2)

Mod client-side dengan sistem modul dan ClickGUI (kategori + toggle ON/OFF).
Modul:
- **Render**: PlayerESP, Tracer, StorageESP, BlockESP, Nametag, Fullbright
- **Combat** (latihan, hanya aktif di world single-player yang tidak dibuka ke LAN): AutoTotem, AutoCrystal, AnchorMacro, AutoShield, AutoAttack
- **Movement**: AutoSprint
- **Misc**: Coords (HUD), Freecam (kecepatan bisa diatur), Freelook, Zoom (FOV bisa diatur)

ESP/Tracer/StorageESP/BlockESP digambar menembus tembok. Gunakan untuk single-player atau server milik sendiri;
banyak server publik melarangnya. Daftar blok BlockESP bisa diubah di `BlockEsp.java`.

## Membuka GUI
- **PC**: `Right Shift` (bisa diubah di Controls).
- **Android / tanpa keyboard**: buka menu pause, tekan tombol **ClickGUI** di pojok kiri atas.

## Build tanpa PC (GitHub Actions)
1. Push repo ke GitHub (pastikan folder `.github` ikut).
2. Tab **Actions** -> run terbaru -> **Artifacts** -> unduh zip, ambil `jetmonclient-1.0.0.jar`.

## Build lokal
Butuh JDK 25 dan Gradle 9.5+: `gradle build` -> `build/libs/jetmonclient-1.0.0.jar`

## Pasang di launcher Android
1. Install Minecraft **26.1.2** + **Fabric Loader** di launcher (mis. Zalith Launcher 2 / PojavLauncher).
2. Pilih runtime **Java 25**.
3. Taruh **Fabric API 26.1.2** dan `jetmonclient-1.0.0.jar` di folder `mods`.

## Menambah modul
Buat class `extends Module` di `module/impl/`, lalu daftarkan di `ModuleManager`.

## Catatan
26.1 memakai nama resmi Mojang (bukan Yarn): `Minecraft`, `Screen`, `GuiGraphicsExtractor`, `KeyMapping`, dst.

## Setting
Modul yang punya pengaturan menampilkan baris tambahan di bawahnya (mis. `Speed: 10`).
Tap tombol `-` / `+` untuk mengubah nilainya.
- **Freecam**: gerak dengan tombol jalan, lompat = naik, sneak = turun. Speed 1-30 blok/detik.
- **Freelook**: otomatis pindah ke third person, mouse memutar kamera tanpa memutar pemain.
- **Zoom**: FOV minimum di Minecraft adalah 30, jadi itu zoom maksimumnya.

## Membuka setting modul
Klik kanan pada modul (atau tap tombol `>` di barisnya) untuk membuka/menutup setting. Geser slider untuk mengubah nilai (tahan lalu geser kiri/kanan).
Setting tersedia untuk: PlayerESP (Mobs), Tracer (Thickness), StorageESP, BlockESP, AutoShield (jarak), AutoCrystal (delay), Freecam (speed), Zoom (FOV).

## StorageESP & BlockESP
- **Tracers**: toggle di setting StorageESP dan BlockESP (garis ke target terdekat).
- **StorageESP**: toggle per jenis wadah (chest, trapped chest, ender chest, shulker, barrel, hopper, dispenser/dropper).
- **BlockESP**: semua blok bisa dipilih. Buka setting BlockESP -> `Blocks (N)` -> ketik di kolom pencarian, tap blok untuk memilih.
  Tombol `+Shown` menambah semua hasil pencarian, `Clear` mengosongkan pilihan. `Max shown` membatasi jumlah blok terdekat yang digambar.

## Opsi gaya Meteor
- **PlayerESP**: Mobs, Invisible, Distance colors, Fill, Outline, Fill opacity, Outline width.
- **Tracer**: Target (Head/Body/Feet), Invisible, Distance colors, Thickness.
- **StorageESP / BlockESP**: Fill, Outline, Fill opacity, Tracers + Thickness.
- **Nametag**: label di layar (tembus tembok) untuk pemain & mob: Players, Mobs, Health, Distance, Background. Hanya di first person.
- **Freecam**: Disable on damage/death/logout, Render hands, Rotate, Mining, Interact, Speed (scroll mouse juga mengubah Speed).
- Panel modul bisa di-scroll dengan tombol `^` `v` kalau barisnya banyak.

## Gear, keybind, dan penyimpanan
- Tiap modul punya tombol **gear** di samping ON/OFF. Tap gear (atau klik kanan modul) untuk membuka setting.
- Baris **Keybind** paling atas di setting: tap, lalu tekan tombol yang diinginkan. Esc atau tap lagi = hapus. Tombol juga bisa diatur di Options > Controls (kategori JetMonClient).
- Status ON/OFF dan semua setting tersimpan di `config/jetmonclient.json`, jadi tetap sama setelah keluar-masuk server dan membuka ulang game. Freecam dan Freelook sengaja tidak dipulihkan.

## Freelook
Bawaan: tekan keybind sekali untuk ON, sekali lagi untuk OFF.
Setting `Hold key` (bawaan OFF): jika dinyalakan, tahan keybind Freelook untuk melihat sekeliling dengan kamera third person belakang,
lepas untuk kembali. Badan pemain tetap menghadap arah semula. Di Pojav/Mojo, pasang tombol layar (mis. "FREE LOOK")
ke tombol yang sama dengan keybind Freelook di JetMonClient.

Catatan: Freelook memakai pemain sebagai kamera, jadi badan pemain tetap terlihat di third person.
Freecam memakai kamera terpisah sehingga badan pemain tidak digambar oleh Minecraft saat freecam.

Freelook punya setting **See through walls**: kamera third person tidak lagi terpotong oleh blok.
Ini satu-satunya mixin di mod ini (`mixin/CameraMixin.java`); jika nama method kamera berbeda di versi game,
opsi ini diam-diam tidak berefek dan mod tetap jalan.

## Halaman setting modul
Tap **gear** di samping ON/OFF (atau klik kanan modul) untuk membuka halaman setting modul itu: Keybind, pilihan, ON/OFF, dan slider.
Tombol **Back** kembali ke daftar modul.

## Mining
- **Freecam**: mining dan klik kanan selalu bisa dari sudut pandang kamera (server membatasi jarak dari tubuh pemain).
- **Freelook**: mining mengikuti arah kamera, jadi kalau kamera melihat ke bawah, yang digali adalah blok di bawah.

## Freecam (pola Glazed)
Gerak per frame (halus), tombol gerak dibaca langsung dari GLFW, sprint 2x, scroll mengubah Speed, FOV effect & view bobbing
dimatikan selama aktif, Stay sneaking, paksa first person, otomatis mati saat respawn atau keluar dunia.
