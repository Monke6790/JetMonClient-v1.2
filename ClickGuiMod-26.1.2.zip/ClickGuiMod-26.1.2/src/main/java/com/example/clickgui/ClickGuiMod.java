package com.example.clickgui;

import com.example.clickgui.gui.ClickGuiScreen;
import com.example.clickgui.module.ModuleManager;
import com.example.clickgui.module.impl.CoordsHud;
import com.example.clickgui.render.ThroughWallsRenderer;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Method;

public class ClickGuiMod implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    private static KeyMapping openGui;

    @Override
    public void onInitializeClient() {
        // PC: Right Shift (bisa diubah di Controls)
        KeyMapping.Category category =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath("jetmonclient", "main"));
        openGui = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.jetmonclient.open", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        // Awal tick: modul yang perlu membaca/mengosongkan input (mis. Freecam)
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            if (client.player != null && client.level != null) MODULES.preTick();
        });

        // Kembalikan pengaturan (FOV, kamera) saat game ditutup
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> MODULES.disableAll());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.consumeClick()) client.setScreen(new ClickGuiScreen());
            if (client.player != null) MODULES.tick();
        });

        // Android / tanpa keyboard: tombol di menu pause
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof PauseScreen) {
                Button b = Button.builder(Component.literal("JetMon"),
                        btn -> client.setScreen(new ClickGuiScreen()))
                    .bounds(8, 8, 80, 20).build();
                addWidget(screen, b);
            }
        });

        ThroughWallsRenderer.init();

        // HUD (Coords)
        HudElementRegistry.attachElementAfter(
            VanillaHudElements.MISC_OVERLAYS,
            Identifier.fromNamespaceAndPath("jetmonclient", "coords"),
            (graphics, tracker) -> MODULES.all().stream()
                .filter(m -> m instanceof CoordsHud)
                .forEach(m -> ((CoordsHud) m).render(graphics)));
    }

    /** Menambah widget ke screen lewat reflection (nama API Fabric berubah-ubah antar versi). */
    private static void addWidget(Screen screen, Button button) {
        try {
            for (Method m : Screen.class.getDeclaredMethods()) {
                if (m.getName().equals("addRenderableWidget") && m.getParameterCount() == 1) {
                    m.setAccessible(true);
                    m.invoke(screen, button);
                    return;
                }
            }
        } catch (ReflectiveOperationException | RuntimeException e) {
            e.printStackTrace();
        }
    }
}
