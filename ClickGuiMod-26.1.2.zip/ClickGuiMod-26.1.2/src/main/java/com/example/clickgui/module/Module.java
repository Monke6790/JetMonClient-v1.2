package com.example.clickgui.module;

import com.example.clickgui.render.WorldShapes;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String name;
    private final Category category;
    private boolean enabled;
    private final List<NumberSetting> settings = new ArrayList<>();
    protected final Minecraft mc = Minecraft.getInstance();

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public String getName() { return name; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public List<NumberSetting> settings() { return settings; }

    protected NumberSetting number(String name, double min, double max, double step, double def) {
        NumberSetting s = new NumberSetting(name, min, max, step, def);
        settings.add(s);
        return s;
    }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (enabled) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}

    /** Awal tick, sebelum pemain diproses (dipakai untuk membaca/mengosongkan input). */
    public void onPreTick() {}
    /** Akhir tick. */
    public void onTick() {}

    /** Dipanggil tiap frame; isi 'shapes' dengan kotak/garis yang mau digambar menembus tembok. */
    public void extract(WorldShapes shapes, float partialTick) {}
}
