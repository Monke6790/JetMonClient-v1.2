package com.example.clickgui.module;

import com.example.clickgui.render.WorldShapes;
import com.google.gson.JsonObject;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String name;
    private final Category category;
    private boolean enabled;
    private final List<NumberSetting> settings = new ArrayList<>();
    private final List<BoolSetting> toggles = new ArrayList<>();
    private final List<ModeSetting> modes = new ArrayList<>();
    private KeyMapping keyMapping;
    protected final Minecraft mc = Minecraft.getInstance();

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public String getName() { return name; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public List<NumberSetting> settings() { return settings; }
    public List<BoolSetting> toggles() { return toggles; }
    public List<ModeSetting> modes() { return modes; }

    protected NumberSetting number(String name, double min, double max, double step, double def) {
        NumberSetting s = new NumberSetting(name, min, max, step, def);
        settings.add(s);
        return s;
    }

    protected BoolSetting bool(String name, boolean def) {
        BoolSetting s = new BoolSetting(name, def);
        toggles.add(s);
        return s;
    }

    protected ModeSetting mode(String name, String def, String... options) {
        ModeSetting s = new ModeSetting(name, def, options);
        modes.add(s);
        return s;
    }

    /** Label baris aksi khusus di panel setting (mis. "Blocks (5)"), atau null jika tidak ada. */
    public String actionLabel() { return null; }
    /** Dijalankan saat baris aksi di-tap. */
    public void runAction(Screen parent) {}

    /** Selalu true: setiap modul punya baris Keybind di panel setting. */
    public boolean hasOptions() { return true; }

    /** Jika true, modul menyala selama keybind ditahan dan mati saat dilepas (bukan toggle). */
    public boolean holdKey() { return false; }
    /** Status internal untuk mode tahan tombol. */
    public boolean keyWasDown, enabledByHold;

    public KeyMapping keyMapping() { return keyMapping; }
    public void setKeyMapping(KeyMapping k) { this.keyMapping = k; }

    /** Apakah status ON/OFF modul ini disimpan dan dipulihkan. Modul kamera: tidak. */
    public boolean persistent() { return true; }

    /** Dipanggil saat pemain masuk dunia/server baru dan modul masih ON. */
    public void onWorldChanged() {
        onDisable();
        onEnable();
    }

    /** Data tambahan yang ikut disimpan ke file konfigurasi. */
    public void saveExtra(JsonObject o) {}
    public void loadExtra(JsonObject o) {}

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (enabled) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}

    public void onPreTick() {}
    public void onTick() {}

    public void extract(WorldShapes shapes, float partialTick) {}

    /** Digambar di HUD tiap frame (teks, label, dll.). */
    public void renderHud(GuiGraphicsExtractor g, float partialTick) {}

    /** Kirim pesan ke chat pemain lewat reflection (tahan perubahan nama method). */
    protected void chat(String text) {
        try {
            for (java.lang.reflect.Method m : mc.player.getClass().getMethods()) {
                if (m.getName().equals("sendSystemMessage") && m.getParameterCount() == 1) {
                    m.invoke(mc.player, Component.literal(text));
                    return;
                }
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
        }
    }
}
