package com.example.clickgui.render;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.Module;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * Menggambar kotak & garis tembus tembok.
 * Garis/tracer digambar sebagai quad tipis (billboard) supaya cukup memakai
 * satu pipeline "filled" saja.
 * Berdasarkan contoh resmi Fabric docs untuk 26.1.2 (Rendering in the World).
 */
public final class ThroughWallsRenderer {
    private static final RenderPipeline FILLED_THROUGH_WALLS = RenderPipelines.register(
        RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath("jetmonclient", "pipeline/filled_through_walls"))
            .withDepthStencilState(Optional.empty())
            .build());

    private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

    private static volatile WorldShapes shapes = new WorldShapes();
    private static MappableRingBuffer vertexBuffer;

    private ThroughWallsRenderer() {}

    public static void init() {
        LevelRenderEvents.END_EXTRACTION.register(ThroughWallsRenderer::extract);
        LevelRenderEvents.AFTER_TRANSLUCENT_TERRAIN.register(ThroughWallsRenderer::draw);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> close());
    }

    // ---------------- Extraction ----------------
    private static void extract(LevelExtractionContext context) {
        Minecraft mc = Minecraft.getInstance();
        WorldShapes s = new WorldShapes();
        if (mc.level != null && mc.player != null) {
            float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
            for (Module m : ClickGuiMod.MODULES.all()) {
                if (m.isEnabled()) m.extract(s, pt);
            }
        }
        shapes = s;
    }

    // ---------------- Drawing ----------------
    private static void draw(LevelRenderContext context) {
        WorldShapes s = shapes;
        if (s.isEmpty()) return;

        Vec3 cam = context.levelState().cameraRenderState.pos;
        Matrix4fc pose = context.poseStack().last().pose();
        BufferBuilder buf = new BufferBuilder(ALLOCATOR,
            FILLED_THROUGH_WALLS.getVertexFormatMode(), FILLED_THROUGH_WALLS.getVertexFormat());

        for (WorldShapes.BoxShape b : s.boxes) {
            if (b.fillAlpha() > 0f) fillBox(buf, pose, cam, b.box(), b.r(), b.g(), b.b(), b.fillAlpha());
            if (b.outlineAlpha() > 0f) outlineBox(buf, pose, cam, b.box(), b.r(), b.g(), b.b(), b.outlineAlpha());
        }
        for (WorldShapes.LineShape l : s.lines) {
            thinLine(buf, pose, cam, l.from(), l.to(), l.thickness(), l.r(), l.g(), l.b(), l.a());
        }

        MeshData built = buf.buildOrThrow();
        MeshData.DrawState dp = built.drawState();
        VertexFormat format = dp.format();
        GpuBuffer vertices = upload(dp, format, built);
        drawBuffer(Minecraft.getInstance(), FILLED_THROUGH_WALLS, built, dp, vertices, format);
        vertexBuffer.rotate();
    }

    // ---------------- Geometri ----------------
    private static void v(BufferBuilder b, Matrix4fc pose, Vec3 cam, double x, double y, double z,
                          float r, float g, float bl, float a) {
        b.addVertex(pose, (float) (x - cam.x), (float) (y - cam.y), (float) (z - cam.z)).setColor(r, g, bl, a);
    }

    private static void fillBox(BufferBuilder b, Matrix4fc p, Vec3 c, AABB bb,
                                float r, float g, float bl, float a) {
        double x0 = bb.minX, y0 = bb.minY, z0 = bb.minZ, x1 = bb.maxX, y1 = bb.maxY, z1 = bb.maxZ;
        // front
        v(b,p,c,x0,y0,z1,r,g,bl,a); v(b,p,c,x1,y0,z1,r,g,bl,a); v(b,p,c,x1,y1,z1,r,g,bl,a); v(b,p,c,x0,y1,z1,r,g,bl,a);
        // back
        v(b,p,c,x1,y0,z0,r,g,bl,a); v(b,p,c,x0,y0,z0,r,g,bl,a); v(b,p,c,x0,y1,z0,r,g,bl,a); v(b,p,c,x1,y1,z0,r,g,bl,a);
        // left
        v(b,p,c,x0,y0,z0,r,g,bl,a); v(b,p,c,x0,y0,z1,r,g,bl,a); v(b,p,c,x0,y1,z1,r,g,bl,a); v(b,p,c,x0,y1,z0,r,g,bl,a);
        // right
        v(b,p,c,x1,y0,z1,r,g,bl,a); v(b,p,c,x1,y0,z0,r,g,bl,a); v(b,p,c,x1,y1,z0,r,g,bl,a); v(b,p,c,x1,y1,z1,r,g,bl,a);
        // top
        v(b,p,c,x0,y1,z1,r,g,bl,a); v(b,p,c,x1,y1,z1,r,g,bl,a); v(b,p,c,x1,y1,z0,r,g,bl,a); v(b,p,c,x0,y1,z0,r,g,bl,a);
        // bottom
        v(b,p,c,x0,y0,z0,r,g,bl,a); v(b,p,c,x1,y0,z0,r,g,bl,a); v(b,p,c,x1,y0,z1,r,g,bl,a); v(b,p,c,x0,y0,z1,r,g,bl,a);
    }

    private static void outlineBox(BufferBuilder b, Matrix4fc p, Vec3 c, AABB bb,
                                   float r, float g, float bl, float a) {
        double dist = c.distanceTo(bb.getCenter());
        double w = Math.max(0.012, dist * 0.0035);
        double x0 = bb.minX, y0 = bb.minY, z0 = bb.minZ, x1 = bb.maxX, y1 = bb.maxY, z1 = bb.maxZ;
        Vec3 a0 = new Vec3(x0,y0,z0), a1 = new Vec3(x1,y0,z0), a2 = new Vec3(x1,y0,z1), a3 = new Vec3(x0,y0,z1);
        Vec3 b0 = new Vec3(x0,y1,z0), b1 = new Vec3(x1,y1,z0), b2 = new Vec3(x1,y1,z1), b3 = new Vec3(x0,y1,z1);
        Vec3[][] edges = {
            {a0,a1},{a1,a2},{a2,a3},{a3,a0},   // bawah
            {b0,b1},{b1,b2},{b2,b3},{b3,b0},   // atas
            {a0,b0},{a1,b1},{a2,b2},{a3,b3}    // tegak
        };
        for (Vec3[] e : edges) lineQuad(b, p, c, e[0], e[1], w, r, g, bl, a);
    }

    private static void lineQuad(BufferBuilder b, Matrix4fc p, Vec3 cam, Vec3 from, Vec3 to,
                                 double width, float r, float g, float bl, float a) {
        Vec3 d = to.subtract(from);
        Vec3 mid = from.add(to).scale(0.5);
        Vec3 side = d.cross(cam.subtract(mid));
        double len = side.length();
        if (len < 1.0e-6) return;
        side = side.scale(width * 0.5 / len);
        Vec3 p1 = from.add(side), p2 = from.subtract(side), p3 = to.subtract(side), p4 = to.add(side);
        // dua arah winding supaya terlihat dari sisi mana pun
        v(b,p,cam,p1.x,p1.y,p1.z,r,g,bl,a); v(b,p,cam,p2.x,p2.y,p2.z,r,g,bl,a);
        v(b,p,cam,p3.x,p3.y,p3.z,r,g,bl,a); v(b,p,cam,p4.x,p4.y,p4.z,r,g,bl,a);
        v(b,p,cam,p4.x,p4.y,p4.z,r,g,bl,a); v(b,p,cam,p3.x,p3.y,p3.z,r,g,bl,a);
        v(b,p,cam,p2.x,p2.y,p2.z,r,g,bl,a); v(b,p,cam,p1.x,p1.y,p1.z,r,g,bl,a);
    }

    // ---------------- Upload + draw (dari contoh resmi Fabric 26.1.2) ----------------
    /**
     * Garis tipis seperti tracer Meteor: lebarnya dihitung dari jarak ke kamera di
     * kedua ujung, jadi di layar tetap ~1 piksel (dikali thickness) dari dekat sampai jauh.
     */
    private static void thinLine(BufferBuilder b, Matrix4fc p, Vec3 cam, Vec3 from, Vec3 to,
                                 float thickness, float r, float g, float bl, float a) {
        Vec3 d = to.subtract(from);
        Vec3 mid = from.add(to).scale(0.5);
        Vec3 side = d.cross(cam.subtract(mid));
        double len = side.length();
        if (len < 1.0e-6) return;
        side = side.scale(1.0 / len);
        double k = 0.002 * thickness * 0.5;
        double wf = Math.max(0.0015, cam.distanceTo(from) * k);
        double wt = Math.max(0.0015, cam.distanceTo(to) * k);
        Vec3 p1 = from.add(side.scale(wf)), p2 = from.subtract(side.scale(wf));
        Vec3 p3 = to.subtract(side.scale(wt)), p4 = to.add(side.scale(wt));
        v(b,p,cam,p1.x,p1.y,p1.z,r,g,bl,a); v(b,p,cam,p2.x,p2.y,p2.z,r,g,bl,a);
        v(b,p,cam,p3.x,p3.y,p3.z,r,g,bl,a); v(b,p,cam,p4.x,p4.y,p4.z,r,g,bl,a);
        v(b,p,cam,p4.x,p4.y,p4.z,r,g,bl,a); v(b,p,cam,p3.x,p3.y,p3.z,r,g,bl,a);
        v(b,p,cam,p2.x,p2.y,p2.z,r,g,bl,a); v(b,p,cam,p1.x,p1.y,p1.z,r,g,bl,a);
    }

    private static GpuBuffer upload(MeshData.DrawState dp, VertexFormat format, MeshData built) {
        int size = dp.vertexCount() * format.getVertexSize();

        if (vertexBuffer == null || vertexBuffer.size() < size) {
            if (vertexBuffer != null) vertexBuffer.close();
            vertexBuffer = new MappableRingBuffer(() -> "clickgui through walls",
                GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, size);
        }

        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (GpuBuffer.MappedView view = encoder.mapBuffer(
                vertexBuffer.currentBuffer().slice(0, built.vertexBuffer().remaining()), false, true)) {
            MemoryUtil.memCopy(built.vertexBuffer(), view.data());
        }
        return vertexBuffer.currentBuffer();
    }

    private static void drawBuffer(Minecraft client, RenderPipeline pipeline, MeshData built,
                                   MeshData.DrawState dp, GpuBuffer vertices, VertexFormat format) {
        GpuBuffer indices;
        VertexFormat.IndexType indexType;

        if (pipeline.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
            built.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
            indices = pipeline.getVertexFormat().uploadImmediateIndexBuffer(built.indexBuffer());
            indexType = built.drawState().indexType();
        } else {
            RenderSystem.AutoStorageIndexBuffer idx = RenderSystem.getSequentialBuffer(pipeline.getVertexFormatMode());
            indices = idx.getBuffer(dp.indexCount());
            indexType = idx.type();
        }

        GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
            .writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

        try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                () -> "clickgui through walls draw",
                client.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
                client.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
            pass.setPipeline(pipeline);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", dynamicTransforms);
            pass.setVertexBuffer(0, vertices);
            pass.setIndexBuffer(indices, indexType);
            //noinspection ConstantValue
            pass.drawIndexed(0 / format.getVertexSize(), 0, dp.indexCount(), 1);
        }
        built.close();
    }

    public static void close() {
        ALLOCATOR.close();
        if (vertexBuffer != null) {
            vertexBuffer.close();
            vertexBuffer = null;
        }
    }
}
