package com.example.clickgui.module.impl;

import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;
import com.example.clickgui.module.util.EntityUtil;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/** ESP menembus tembok untuk pemain. Opsi mirip ESP Meteor: fill/outline, opacity, warna jarak. */
public class PlayerEsp extends Module {
    private final BoolSetting mobs = bool("Mobs", false);
    private final BoolSetting invisible = bool("Invisible", true);
    private final BoolSetting distanceColors = bool("Distance colors", false);
    private final BoolSetting fill = bool("Fill", true);
    private final BoolSetting outline = bool("Outline", true);
    private final NumberSetting opacity = number("Fill opacity", 5, 100, 5, 25);
    private final NumberSetting width = number("Outline width", 0.5, 5, 0.5, 1.5);

    public PlayerEsp() { super("PlayerESP", Category.RENDER); }

    @Override
    public void extract(WorldShapes shapes, float pt) {
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!EntityUtil.isTarget(e)) continue;
            if (!(e instanceof Player) && !mobs.get()) continue;
            if (!invisible.get() && e.isInvisible()) continue;

            float[] color = distanceColors.get()
                ? EntityUtil.distanceColor(mc.player.distanceTo(e))
                : EntityUtil.color(e);
            shapes.box(EntityUtil.box(e, pt), color,
                fill.get() ? (float) opacity.get() / 100f : 0f,
                outline.get() ? 0.95f : 0f,
                (float) width.get());
        }
    }
}
