package com.example.clickgui.module.impl;

import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.util.EntityUtil;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/** Kotak ESP menembus tembok untuk pemain lain. Mob bisa dinyalakan lewat setting "Mobs". */
public class PlayerEsp extends Module {
    private final BoolSetting mobs = bool("Mobs", false);

    public PlayerEsp() { super("PlayerESP", Category.RENDER); }

    @Override
    public void extract(WorldShapes shapes, float pt) {
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!EntityUtil.isTarget(e)) continue;
            if (!(e instanceof Player) && !mobs.get()) continue;
            shapes.box(EntityUtil.box(e, pt), EntityUtil.color(e), 0.22f, 0.95f);
        }
    }
}
