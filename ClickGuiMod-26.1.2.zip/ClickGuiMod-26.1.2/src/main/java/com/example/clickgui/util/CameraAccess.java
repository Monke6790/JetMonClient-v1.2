package com.example.clickgui.util;

import net.minecraft.client.Camera;

import java.lang.reflect.Field;

/** Mengubah field privat Camera.detached lewat reflection (tidak crash jika namanya berbeda). */
public final class CameraAccess {
    private static Field detachedField;
    private static boolean failed;

    private CameraAccess() {}

    public static void setDetached(Camera camera, boolean value) {
        if (failed) return;
        try {
            if (detachedField == null) {
                detachedField = Camera.class.getDeclaredField("detached");
                detachedField.setAccessible(true);
            }
            detachedField.setBoolean(camera, value);
        } catch (Throwable t) {
            failed = true;
        }
    }
}
