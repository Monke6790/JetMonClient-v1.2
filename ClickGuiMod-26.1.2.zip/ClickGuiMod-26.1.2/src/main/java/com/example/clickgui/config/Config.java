package com.example.clickgui.config;

import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.ModeSetting;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.ModuleManager;
import com.example.clickgui.module.NumberSetting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Menyimpan status ON/OFF modul dan semua setting ke config/jetmonclient.json,
 * supaya tetap sama setelah keluar-masuk server maupun membuka ulang game.
 * Keybind disimpan otomatis oleh Minecraft di options.txt.
 */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("jetmonclient.json");
    }

    public static void save(ModuleManager manager) {
        try {
            JsonObject mods = new JsonObject();
            for (Module m : manager.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.persistent() && m.isEnabled());
                JsonObject numbers = new JsonObject();
                for (NumberSetting s : m.settings()) numbers.addProperty(s.getName(), s.get());
                o.add("numbers", numbers);
                JsonObject toggles = new JsonObject();
                for (BoolSetting s : m.toggles()) toggles.addProperty(s.getName(), s.get());
                o.add("toggles", toggles);
                JsonObject modes = new JsonObject();
                for (ModeSetting s : m.modes()) modes.addProperty(s.getName(), s.get());
                o.add("modes", modes);
                m.saveExtra(o);
                mods.add(m.getName(), o);
            }
            JsonObject root = new JsonObject();
            root.add("modules", mods);
            Files.createDirectories(file().getParent());
            Files.writeString(file(), GSON.toJson(root));
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public static void load(ModuleManager manager) {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            JsonObject mods = root.getAsJsonObject("modules");
            if (mods == null) return;

            for (Module m : manager.all()) {
                if (!mods.has(m.getName())) continue;
                JsonObject o = mods.getAsJsonObject(m.getName());

                JsonObject numbers = o.has("numbers") ? o.getAsJsonObject("numbers") : null;
                if (numbers != null) {
                    for (NumberSetting s : m.settings()) {
                        if (numbers.has(s.getName())) s.set(numbers.get(s.getName()).getAsDouble());
                    }
                }
                JsonObject toggles = o.has("toggles") ? o.getAsJsonObject("toggles") : null;
                if (toggles != null) {
                    for (BoolSetting s : m.toggles()) {
                        if (toggles.has(s.getName())) s.set(toggles.get(s.getName()).getAsBoolean());
                    }
                }
                JsonObject modes = o.has("modes") ? o.getAsJsonObject("modes") : null;
                if (modes != null) {
                    for (ModeSetting s : m.modes()) {
                        if (modes.has(s.getName())) s.set(modes.get(s.getName()).getAsString());
                    }
                }
                m.loadExtra(o);

                // Status ON/OFF terakhir, setelah setting terpasang
                if (m.persistent() && o.has("enabled") && o.get("enabled").getAsBoolean()) m.setEnabled(true);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
