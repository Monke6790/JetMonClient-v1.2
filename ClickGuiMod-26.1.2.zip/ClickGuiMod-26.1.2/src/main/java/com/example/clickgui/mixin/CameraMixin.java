package com.example.clickgui.mixin;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.impl.Freelook;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Kamera third person biasanya "mundur" saat menabrak blok. Saat Freelook aktif dan
 * "See through walls" menyala, jarak kamera tidak dipotong oleh blok.
 * require = 0: kalau nama method berbeda di versi ini, injeksi dilewati (tidak crash).
 */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Inject(method = "getMaxZoom", at = @At("HEAD"), cancellable = true, require = 0)
    private void jetmon$seeThroughWalls(float maxZoom, CallbackInfoReturnable<Float> cir) {
        Freelook f = ClickGuiMod.MODULES.freelook;
        if (f.isEnabled() && f.seeThroughWalls()) cir.setReturnValue(maxZoom);
    }
}
