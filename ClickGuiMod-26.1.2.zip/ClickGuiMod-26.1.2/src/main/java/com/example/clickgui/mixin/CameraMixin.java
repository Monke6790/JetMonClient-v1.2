package com.example.clickgui.mixin;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.impl.Freecam;
import com.example.clickgui.module.impl.Freelook;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/**
 * Kamera tetap memakai pemain sebagai entity-nya. Mixin ini:
 *  - Freecam: mengganti posisi & rotasi kamera, menandai "detached" agar badan pemain tetap digambar.
 *  - Freelook: mengganti rotasi kamera (arah hadap pemain tidak berubah).
 *  - Jarak third person: 0 saat Freecam, tembus blok saat Freelook "See through walls".
 * Semua injeksi memakai require = 0: jika target tidak ada di versi ini, dilewati tanpa crash.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

    /** Awal setup kamera tiap frame: majukan posisi freecam. */
    @Inject(method = "setup", at = @At("HEAD"), require = 0)
    private void jetmon$stepFreecam(Level level, Entity entity, boolean thirdPerson, boolean inverseView,
                                    float tickDelta, CallbackInfo ci) {
        MixinStatus.cameraSetup = true;
        Freecam f = ClickGuiMod.MODULES.freecam;
        if (f.isEnabled()) f.onCameraSetup();
    }

    /** Ganti posisi kamera dengan posisi freecam. */
    @ModifyArgs(method = "setup",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setPosition(DDD)V"),
        require = 0)
    private void jetmon$freecamPosition(Args args) {
        Freecam f = ClickGuiMod.MODULES.freecam;
        if (!f.isEnabled() || !f.cameraReady()) return;
        args.set(0, f.camX());
        args.set(1, f.camY());
        args.set(2, f.camZ());
        MixinStatus.positionApplied = true;
    }

    /** Ganti rotasi kamera dengan rotasi Freecam / Freelook. */
    @ModifyArgs(method = "setup",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setRotation(FF)V"),
        require = 0)
    private void jetmon$cameraRotation(Args args) {
        Freecam fc = ClickGuiMod.MODULES.freecam;
        if (fc.isEnabled() && fc.cameraReady()) {
            args.set(0, fc.yaw());
            args.set(1, fc.pitch());
            MixinStatus.rotationApplied = true;
            return;
        }
        Freelook fl = ClickGuiMod.MODULES.freelook;
        if (fl.isEnabled() && fl.cameraReady()) {
            args.set(0, fl.yaw());
            args.set(1, fl.pitch());
            MixinStatus.rotationApplied = true;
        }
    }

    /** Akhir setup: tandai detached agar badan pemain ikut digambar saat freecam. */
    @Inject(method = "setup", at = @At("TAIL"), require = 0)
    private void jetmon$showBody(Level level, Entity entity, boolean thirdPerson, boolean inverseView,
                                 float tickDelta, CallbackInfo ci) {
        Freecam f = ClickGuiMod.MODULES.freecam;
        if (f.isEnabled() && f.cameraReady()) CameraAccess.setDetached((Camera) (Object) this, true);
    }

    /** Jarak third person: 0 saat freecam (tidak mundur), tembus blok saat Freelook "See through walls". */
    @Inject(method = "getMaxZoom", at = @At("HEAD"), cancellable = true, require = 0)
    private void jetmon$maxZoom(float maxZoom, CallbackInfoReturnable<Float> cir) {
        Freecam fc = ClickGuiMod.MODULES.freecam;
        if (fc.isEnabled() && fc.cameraReady()) {
            cir.setReturnValue(0.0f);
            return;
        }
        Freelook fl = ClickGuiMod.MODULES.freelook;
        if (fl.isEnabled() && fl.seeThroughWalls()) cir.setReturnValue(maxZoom);
    }
}
