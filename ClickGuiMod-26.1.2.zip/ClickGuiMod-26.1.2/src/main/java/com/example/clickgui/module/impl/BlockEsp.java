package com.example.clickgui.module.impl;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BlockEsp extends Module {
    private static final int RADIUS = 16;
    private static final int MAX_RESULTS = 1500;
    private static final Map<Block, float[]> TARGETS = new HashMap<>();

    static {
        // Edit daftar ini sesuai kebutuhan
        float[] diamond = {0.3f, 0.9f, 1.0f};
        TARGETS.put(Blocks.DIAMOND_ORE, diamond);
        TARGETS.put(Blocks.DEEPSLATE_DIAMOND_ORE, diamond);
        float[] emerald = {0.2f, 1.0f, 0.3f};
        TARGETS.put(Blocks.EMERALD_ORE, emerald);
        TARGETS.put(Blocks.DEEPSLATE_EMERALD_ORE, emerald);
        float[] gold = {1.0f, 0.85f, 0.1f};
        TARGETS.put(Blocks.GOLD_ORE, gold);
        TARGETS.put(Blocks.DEEPSLATE_GOLD_ORE, gold);
        TARGETS.put(Blocks.NETHER_GOLD_ORE, gold);
        TARGETS.put(Blocks.ANCIENT_DEBRIS, new float[]{0.8f, 0.4f, 0.2f});
        TARGETS.put(Blocks.SPAWNER, new float[]{0.6f, 0.2f, 1.0f});
    }

    private record Found(AABB box, float[] color) {}
    private volatile List<Found> found = List.of();

    public BlockEsp() { super("BlockESP", Category.RENDER); }

    @Override protected void onEnable() { scan(); }
    @Override protected void onDisable() { found = List.of(); }

    @Override
    public void onTick() {
        if (mc.player != null && mc.player.tickCount % 40 == 0) scan();
    }

    private void scan() {
        if (mc.level == null || mc.player == null) return;
        int px = mc.player.getBlockX(), py = mc.player.getBlockY(), pz = mc.player.getBlockZ();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        List<Found> out = new ArrayList<>();
        outer:
        for (int x = px - RADIUS; x <= px + RADIUS; x++) {
            for (int z = pz - RADIUS; z <= pz + RADIUS; z++) {
                for (int y = py - RADIUS; y <= py + RADIUS; y++) {
                    mp.set(x, y, z);
                    float[] c = TARGETS.get(mc.level.getBlockState(mp).getBlock());
                    if (c == null) continue;
                    out.add(new Found(new AABB(x, y, z, x + 1, y + 1, z + 1), c));
                    if (out.size() >= MAX_RESULTS) break outer;
                }
            }
        }
        found = out;
    }

    @Override
    public void extract(WorldShapes shapes, float pt) {
        for (Found f : found) shapes.box(f.box(), f.color(), 0.25f, 0.95f);
    }
}
