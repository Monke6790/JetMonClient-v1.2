package com.example.clickgui.module.impl;

import com.example.clickgui.gui.BlockPickerScreen;
import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;
import com.example.clickgui.module.util.EntityUtil;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** ESP untuk blok apa pun. Pilih blok lewat layar pencarian (Setting -> Blocks). */
public class BlockEsp extends Module {
    private static final int MAX_TRACERS = 64;
    private static final Map<Block, float[]> PRESET = new HashMap<>();

    static {
        float[] diamond = {0.3f, 0.9f, 1.0f};
        PRESET.put(Blocks.DIAMOND_ORE, diamond);
        PRESET.put(Blocks.DEEPSLATE_DIAMOND_ORE, diamond);
        float[] emerald = {0.2f, 1.0f, 0.3f};
        PRESET.put(Blocks.EMERALD_ORE, emerald);
        PRESET.put(Blocks.DEEPSLATE_EMERALD_ORE, emerald);
        float[] gold = {1.0f, 0.85f, 0.1f};
        PRESET.put(Blocks.GOLD_ORE, gold);
        PRESET.put(Blocks.DEEPSLATE_GOLD_ORE, gold);
        PRESET.put(Blocks.NETHER_GOLD_ORE, gold);
        PRESET.put(Blocks.ANCIENT_DEBRIS, new float[]{0.8f, 0.4f, 0.2f});
        PRESET.put(Blocks.SPAWNER, new float[]{0.6f, 0.2f, 1.0f});
    }

    private record Hit(int x, int y, int z, Block block, double d2) {}
    private record Found(AABB box, float[] color, Vec3 center) {}

    private final Set<Block> selected = new HashSet<>();
    private final Map<Block, float[]> colorCache = new HashMap<>();
    private volatile List<Found> found = List.of();

    private final BoolSetting tracers = bool("Tracers", false);
    private final NumberSetting radius = number("Radius", 4, 24, 2, 16);
    private final NumberSetting maxShown = number("Max shown", 100, 3000, 100, 1000);
    private final NumberSetting thickness = number("Thickness", 0.5, 5, 0.5, 1);

    public BlockEsp() {
        super("BlockESP", Category.RENDER);
        selected.addAll(PRESET.keySet());
    }

    public Set<Block> selected() { return selected; }

    public static String idOf(Block b) {
        return BuiltInRegistries.BLOCK.getKey(b).toString().replace("minecraft:", "");
    }

    /** Warna blok: preset untuk ore populer, selain itu dari hash nama supaya konsisten. */
    public float[] colorOf(Block b) {
        float[] c = PRESET.get(b);
        if (c != null) return c;
        return colorCache.computeIfAbsent(b, k -> {
            float hue = (idOf(k).hashCode() & 0x7fffffff) % 360 / 360f;
            return hsv(hue, 0.7f, 1.0f);
        });
    }

    private static float[] hsv(float h, float s, float v) {
        float hh = (h - (float) Math.floor(h)) * 6f;
        int i = (int) hh;
        float f = hh - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        return switch (i) {
            case 0 -> new float[]{v, t, p};
            case 1 -> new float[]{q, v, p};
            case 2 -> new float[]{p, v, t};
            case 3 -> new float[]{p, q, v};
            case 4 -> new float[]{t, p, v};
            default -> new float[]{v, p, q};
        };
    }

    @Override public String actionLabel() { return "Blocks (" + selected.size() + ")"; }

    @Override
    public void runAction(Screen parent) {
        mc.setScreen(new BlockPickerScreen(parent, this));
    }

    @Override protected void onEnable() { scan(); }
    @Override protected void onDisable() { found = List.of(); }

    @Override
    public void onTick() {
        if (mc.player != null && mc.player.tickCount % 40 == 0) scan();
    }

    private void scan() {
        if (mc.level == null || mc.player == null || selected.isEmpty()) { found = List.of(); return; }
        int px = mc.player.getBlockX(), py = mc.player.getBlockY(), pz = mc.player.getBlockZ();
        int rad = (int) radius.get();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        List<Hit> hits = new ArrayList<>();
        for (int x = px - rad; x <= px + rad; x++) {
            for (int z = pz - rad; z <= pz + rad; z++) {
                for (int y = py - rad; y <= py + rad; y++) {
                    mp.set(x, y, z);
                    Block b = mc.level.getBlockState(mp).getBlock();
                    if (!selected.contains(b)) continue;
                    double dx = x - px, dy = y - py, dz = z - pz;
                    hits.add(new Hit(x, y, z, b, dx * dx + dy * dy + dz * dz));
                }
            }
        }
        hits.sort(Comparator.comparingDouble(Hit::d2));
        int n = Math.min(hits.size(), (int) maxShown.get());
        List<Found> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            Hit h = hits.get(i);
            AABB box = new AABB(h.x(), h.y(), h.z(), h.x() + 1, h.y() + 1, h.z() + 1);
            out.add(new Found(box, colorOf(h.block()), box.getCenter()));
        }
        found = out;
    }

    @Override
    public void extract(WorldShapes shapes, float pt) {
        List<Found> list = found;
        for (Found f : list) shapes.box(f.box(), f.color(), 0.25f, 0.95f);
        if (tracers.get()) {
            Vec3 start = EntityUtil.tracerStart(pt);
            int n = Math.min(MAX_TRACERS, list.size());
            for (int i = 0; i < n; i++) shapes.line(start, list.get(i).center(), list.get(i).color(), 0.9f, (float) thickness.get());
        }
    }
}
