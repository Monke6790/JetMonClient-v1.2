package com.example.clickgui.module.combat;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.EntityHitResult;

/** Menyerang otomatis saat crosshair mengarah ke makhluk hidup dan cooldown serangan penuh. */
public class AutoAttack extends CombatModule {
    public AutoAttack() { super("AutoAttack"); }

    @Override
    protected void combatTick() {
        if (!(mc.hitResult instanceof EntityHitResult hit)) return;
        Entity target = hit.getEntity();
        if (!(target instanceof LivingEntity) || target instanceof ArmorStand || !target.isAlive()) return;
        if (mc.player.getAttackStrengthScale(0.5f) < 1.0f) return;

        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }
}
