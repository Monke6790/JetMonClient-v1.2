package com.example.clickgui.module.util;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.impl.Freecam;
import com.example.clickgui.module.impl.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Posisi dan arah pandang kamera yang sedang dipakai (Freecam / Freelook / normal). */
public final class ViewState {
    private ViewState() {}

    public static Vec3 position(Entity cam, float pt) {
        Freecam fc = ClickGuiMod.MODULES.freecam;
        if (fc.isEnabled() && fc.cameraReady()) return new Vec3(fc.camX(), fc.camY(), fc.camZ());
        return cam.getEyePosition(pt);
    }

    public static float yaw(Entity cam, float pt) {
        Freecam fc = ClickGuiMod.MODULES.freecam;
        if (fc.isEnabled() && fc.cameraReady()) return fc.yaw();
        Freelook fl = ClickGuiMod.MODULES.freelook;
        if (fl.isEnabled() && fl.cameraReady()) return fl.yaw();
        return cam.getViewYRot(pt);
    }

    public static float pitch(Entity cam, float pt) {
        Freecam fc = ClickGuiMod.MODULES.freecam;
        if (fc.isEnabled() && fc.cameraReady()) return fc.pitch();
        Freelook fl = ClickGuiMod.MODULES.freelook;
        if (fl.isEnabled() && fl.cameraReady()) return fl.pitch();
        return cam.getViewXRot(pt);
    }

    public static Vec3 direction(Entity cam, float pt) {
        double yaw = Math.toRadians(yaw(cam, pt)), pitch = Math.toRadians(pitch(cam, pt));
        return new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
    }

    public static Entity player() { return Minecraft.getInstance().player; }
}
