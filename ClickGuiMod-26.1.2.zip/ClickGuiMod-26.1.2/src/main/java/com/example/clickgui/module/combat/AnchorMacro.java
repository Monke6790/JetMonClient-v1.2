package com.example.clickgui.module.combat;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Saat crosshair mengarah ke respawn anchor: isi dengan glowstone, lalu ledakkan
 * dengan item lain. Hati-hati, ledakan bisa mengenai pemain sendiri.
 */
public class AnchorMacro extends CombatModule {
    private int cooldown;

    public AnchorMacro() { super("AnchorMacro"); }

    @Override
    protected void combatTick() {
        if (cooldown > 0) { cooldown--; return; }
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() == HitResult.Type.MISS) return;

        BlockPos pos = hit.getBlockPos();
        BlockState state = mc.level.getBlockState(pos);
        if (!state.is(Blocks.RESPAWN_ANCHOR)) return;

        int charge = state.getValue(RespawnAnchorBlock.CHARGE);
        if (charge == 0) {
            if (!holding(s -> s.is(Items.GLOWSTONE))) return;      // isi
        } else {
            if (!holding(s -> !s.isEmpty() && !s.is(Items.GLOWSTONE))) return; // ledakkan
        }
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hit);
        mc.player.swing(InteractionHand.MAIN_HAND);
        cooldown = 2;
    }
}
