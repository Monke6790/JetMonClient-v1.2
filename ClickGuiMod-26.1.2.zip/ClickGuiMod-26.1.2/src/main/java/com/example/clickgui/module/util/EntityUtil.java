package com.example.clickgui.module.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

public final class EntityUtil {
    private EntityUtil() {}

    public static final float[] PLAYER = {1.0f, 0.25f, 0.25f};
    public static final float[] HOSTILE = {1.0f, 0.6f, 0.1f};
    public static final float[] PASSIVE = {0.3f, 1.0f, 0.4f};

    public static boolean isTarget(Entity e) {
        Minecraft mc = Minecraft.getInstance();
        return e instanceof LivingEntity && e != mc.player && !(e instanceof ArmorStand);
    }

    public static float[] color(Entity e) {
        if (e instanceof Player) return PLAYER;
        if (e instanceof Enemy) return HOSTILE;
        return PASSIVE;
    }

    /** Bounding box yang sudah di-interpolasi supaya halus. */
    public static AABB box(Entity e, float pt) {
        return e.getBoundingBox().move(e.getPosition(pt).subtract(e.position()));
    }
}
