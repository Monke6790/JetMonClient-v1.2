package com.example.clickgui.module.util;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.impl.Freecam;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class EntityUtil {
    private EntityUtil() {}

    public static final float[] PLAYER = {1.0f, 0.25f, 0.25f};
    public static final float[] HOSTILE = {1.0f, 0.6f, 0.1f};
    public static final float[] PASSIVE = {0.3f, 1.0f, 0.4f};

    public static boolean isTarget(Entity e) {
        Minecraft mc = Minecraft.getInstance();
        return e instanceof LivingEntity && e != mc.player && !(e instanceof ArmorStand);
    }

    public static float[] color(Entity e) {
        if (e instanceof Player) return PLAYER;
        if (e instanceof Enemy) return HOSTILE;
        return PASSIVE;
    }

    /** Bounding box yang sudah di-interpolasi supaya halus. */
    public static AABB box(Entity e, float pt) {
        return e.getBoundingBox().move(e.getPosition(pt).subtract(e.position()));
    }

    /** Titik awal garis tracer: sedikit di depan kamera supaya tidak terpotong near-plane. */
    public static Vec3 tracerStart(float pt) {
        Minecraft mc = Minecraft.getInstance();
        Freecam fc = ClickGuiMod.MODULES.freecam;
        Vec3 base = (fc.isEnabled() && fc.cameraReady())
            ? new Vec3(fc.camX(), fc.camY(), fc.camZ())
            : mc.player.getEyePosition(pt);
        return base.add(mc.player.getViewVector(pt).scale(1.0));
    }

    /** Merah saat dekat, hijau saat jauh (seperti "distance colors" di ESP Meteor). */
    public static float[] distanceColor(double distance) {
        float t = (float) Math.min(1.0, distance / 60.0);
        return new float[]{1.0f - t, t, 0.1f};
    }
}
