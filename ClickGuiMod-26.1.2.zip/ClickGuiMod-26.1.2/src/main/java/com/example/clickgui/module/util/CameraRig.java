package com.example.clickgui.module.util;

import com.example.clickgui.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Kamera terpisah dari pemain (dipakai Freecam & Freelook).
 * Kamera adalah entity Marker client-side. Gerakan mouse yang biasanya memutar pemain
 * dialihkan untuk memutar kamera, lalu rotasi pemain dikembalikan ke nilai referensi.
 */
public final class CameraRig {
    private static Marker cam;
    private static Module owner;
    /** Rotasi asli pemain (dikembalikan saat rig berhenti). */
    private static float origYaw, origPitch;
    /** Rotasi acuan pemain selama rig aktif (bisa diubah lewat aimPlayer). */
    private static float refYaw, refPitch;

    private CameraRig() {}

    public static Marker camera() { return cam; }
    public static boolean ownedBy(Module m) { return cam != null && owner == m; }

    public static boolean valid(Module m) {
        Minecraft mc = Minecraft.getInstance();
        return cam != null && owner == m && mc.level != null && cam.level() == mc.level;
    }

    public static void start(Module newOwner, Vec3 pos) {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.level == null) return;

        // Hanya satu modul boleh memakai kamera: matikan pemilik sebelumnya
        if (cam != null && owner != null && owner != newOwner) {
            Module prev = owner;
            prev.setEnabled(false);
        }
        owner = newOwner;
        origYaw = p.getYRot();
        origPitch = p.getXRot();
        refYaw = origYaw;
        refPitch = 0f;

        cam = new Marker(EntityType.MARKER, mc.level);
        cam.setPos(pos.x, pos.y, pos.z);
        cam.setYRot(origYaw);
        cam.setXRot(origPitch);
        syncOld();

        p.setXRot(refPitch);
        p.xRotO = refPitch;
        mc.setCameraEntity(cam);
    }

    public static void stop(Module who) {
        if (cam == null || owner != who) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.player.setYRot(origYaw);
            mc.player.yRotO = origYaw;
            mc.player.setXRot(origPitch);
            mc.player.xRotO = origPitch;
            mc.setCameraEntity(mc.player);
        }
        cam = null;
        owner = null;
    }

    /** Arahkan tubuh pemain (bukan kamera) ke yaw/pitch tertentu, mis. ke blok yang diklik. */
    public static void aimPlayer(float yaw, float pitch) {
        Player p = Minecraft.getInstance().player;
        if (cam == null || p == null) return;
        refYaw = yaw;
        refPitch = pitch;
        p.setYRot(yaw);
        p.yRotO = yaw;
        p.setXRot(pitch);
        p.xRotO = pitch;
    }

    /** Pindahkan putaran mouse (yang masuk ke pemain) ke kamera, lalu kembalikan rotasi pemain. */
    public static void pumpRotation() {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (cam == null || p == null) return;

        float dy = p.getYRot() - refYaw;
        float dp = p.getXRot() - refPitch;
        if (dy != 0f || dp != 0f) {
            cam.setYRot(cam.getYRot() + dy);
            cam.setXRot(Mth.clamp(cam.getXRot() + dp, -90f, 90f));
            p.setYRot(refYaw);
            p.setXRot(refPitch);
            p.yRotO = refYaw;
            p.xRotO = refPitch;
        }
        cam.yRotO = cam.getYRot();
        cam.xRotO = cam.getXRot();
    }

    /** Samakan posisi/rotasi lama dengan yang sekarang (tanpa interpolasi). */
    public static void syncOld() {
        if (cam == null) return;
        cam.xo = cam.getX();
        cam.yo = cam.getY();
        cam.zo = cam.getZ();
        cam.yRotO = cam.getYRot();
        cam.xRotO = cam.getXRot();
    }
}
