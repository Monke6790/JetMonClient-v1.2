package com.example.clickgui.module.impl;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;

/**
 * Zoom lewat pengaturan FOV. Batas bawah FOV di Minecraft adalah 30,
 * jadi zoom maksimum = FOV 30.
 */
public class Zoom extends Module {
    public final NumberSetting fov = number("FOV", 30, 90, 5, 30);
    private int originalFov = -1;

    public Zoom() { super("Zoom", Category.MISC); }

    @Override
    protected void onEnable() {
        originalFov = mc.options.fov().get();
    }

    @Override
    public void onTick() {
        int target = (int) Math.round(fov.get());
        if (mc.options.fov().get() != target) mc.options.fov().set(target);
    }

    @Override
    protected void onDisable() {
        if (originalFov > 0) mc.options.fov().set(originalFov);
        originalFov = -1;
    }
}
