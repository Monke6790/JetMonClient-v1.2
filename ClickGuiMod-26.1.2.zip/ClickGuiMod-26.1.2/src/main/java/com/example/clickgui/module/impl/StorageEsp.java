package com.example.clickgui.module.impl;

import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;
import com.example.clickgui.module.util.EntityUtil;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class StorageEsp extends Module {
    private static final int MAX_TRACERS = 128;

    private record Found(AABB box, float[] color, Vec3 center, double d2) {}
    private volatile List<Found> found = List.of();

    // Urutan di sini = urutan tampil di panel setting
    private final BoolSetting tracers = bool("Tracers", false);
    private final BoolSetting chests = bool("Chests", true);
    private final BoolSetting trapped = bool("Trapped chests", true);
    private final BoolSetting ender = bool("Ender chests", true);
    private final BoolSetting shulkers = bool("Shulker boxes", true);
    private final BoolSetting barrels = bool("Barrels", true);
    private final BoolSetting hoppers = bool("Hoppers", true);
    private final BoolSetting dispensers = bool("Dispensers/Droppers", true);
    private final NumberSetting chunks = number("Chunks", 2, 12, 1, 8);

    public StorageEsp() { super("StorageESP", Category.RENDER); }

    @Override protected void onEnable() { scan(); }
    @Override protected void onDisable() { found = List.of(); }

    @Override
    public void onTick() {
        if (mc.player != null && mc.player.tickCount % 20 == 0) scan();
    }

    private void scan() {
        if (mc.level == null || mc.player == null) return;
        int r = Math.min(mc.options.renderDistance().get(), (int) chunks.get());
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        Vec3 me = mc.player.position();
        List<Found> out = new ArrayList<>();
        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                LevelChunk chunk = mc.level.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    float[] c = colorFor(be);
                    if (c == null) continue;
                    BlockPos p = be.getBlockPos();
                    AABB box = new AABB(p.getX() + 0.06, p.getY(), p.getZ() + 0.06,
                        p.getX() + 0.94, p.getY() + 0.88, p.getZ() + 0.94);
                    Vec3 center = box.getCenter();
                    out.add(new Found(box, c, center, me.distanceToSqr(center)));
                }
            }
        }
        out.sort(Comparator.comparingDouble(Found::d2));
        found = out;
    }

    private float[] colorFor(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return trapped.get() ? new float[]{1.0f, 0.2f, 0.2f} : null;
        if (be instanceof ChestBlockEntity) return chests.get() ? new float[]{1.0f, 0.65f, 0.1f} : null;
        if (be instanceof EnderChestBlockEntity) return ender.get() ? new float[]{0.7f, 0.3f, 1.0f} : null;
        if (be instanceof ShulkerBoxBlockEntity) return shulkers.get() ? new float[]{1.0f, 0.4f, 0.8f} : null;
        if (be instanceof BarrelBlockEntity) return barrels.get() ? new float[]{0.7f, 0.5f, 0.25f} : null;
        if (be instanceof HopperBlockEntity) return hoppers.get() ? new float[]{0.6f, 0.6f, 0.6f} : null;
        if (be instanceof DispenserBlockEntity) return dispensers.get() ? new float[]{0.5f, 0.75f, 0.9f} : null;
        return null;
    }

    @Override
    public void extract(WorldShapes shapes, float pt) {
        List<Found> list = found;
        for (Found f : list) shapes.box(f.box(), f.color(), 0.2f, 0.95f);
        if (tracers.get()) {
            Vec3 start = EntityUtil.tracerStart(pt);
            int n = Math.min(MAX_TRACERS, list.size());
            for (int i = 0; i < n; i++) shapes.line(start, list.get(i).center(), list.get(i).color(), 0.9f);
        }
    }
}
