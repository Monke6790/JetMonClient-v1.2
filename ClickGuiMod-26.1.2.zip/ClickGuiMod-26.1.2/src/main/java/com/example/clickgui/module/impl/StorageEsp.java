package com.example.clickgui.module.impl;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

public class StorageEsp extends Module {
    private record Found(AABB box, float[] color) {}
    private volatile List<Found> found = List.of();

    public StorageEsp() { super("StorageESP", Category.RENDER); }

    @Override protected void onEnable() { scan(); }
    @Override protected void onDisable() { found = List.of(); }

    @Override
    public void onTick() {
        if (mc.player != null && mc.player.tickCount % 20 == 0) scan();
    }

    private void scan() {
        if (mc.level == null || mc.player == null) return;
        int r = Math.min(mc.options.renderDistance().get(), 12);
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        List<Found> out = new ArrayList<>();
        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                LevelChunk chunk = mc.level.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    float[] c = colorFor(be);
                    if (c == null) continue;
                    BlockPos p = be.getBlockPos();
                    out.add(new Found(new AABB(p.getX() + 0.06, p.getY(), p.getZ() + 0.06,
                        p.getX() + 0.94, p.getY() + 0.88, p.getZ() + 0.94), c));
                }
            }
        }
        found = out;
    }

    private static float[] colorFor(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return new float[]{1.0f, 0.2f, 0.2f};
        if (be instanceof ChestBlockEntity) return new float[]{1.0f, 0.65f, 0.1f};
        if (be instanceof EnderChestBlockEntity) return new float[]{0.7f, 0.3f, 1.0f};
        if (be instanceof ShulkerBoxBlockEntity) return new float[]{1.0f, 0.4f, 0.8f};
        if (be instanceof BarrelBlockEntity) return new float[]{0.7f, 0.5f, 0.25f};
        if (be instanceof HopperBlockEntity) return new float[]{0.6f, 0.6f, 0.6f};
        if (be instanceof DispenserBlockEntity) return new float[]{0.5f, 0.75f, 0.9f};
        return null;
    }

    @Override
    public void extract(WorldShapes shapes, float pt) {
        for (Found f : found) shapes.box(f.box(), f.color(), 0.2f, 0.95f);
    }
}
