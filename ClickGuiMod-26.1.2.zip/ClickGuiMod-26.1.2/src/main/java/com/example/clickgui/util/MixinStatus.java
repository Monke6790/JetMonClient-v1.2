package com.example.clickgui.util;

/** Penanda bahwa tiap injeksi mixin benar-benar terpanggil (untuk diagnostik di game). */
public final class MixinStatus {
    public static volatile boolean cameraSetup;      // Camera.setup terpanggil
    public static volatile boolean positionApplied;  // Camera.setPosition(DDD) diganti
    public static volatile boolean rotationApplied;  // Camera.setRotation(FF) diganti
    public static volatile boolean turnSeen;         // Entity.turn terpanggil untuk pemain
    public static volatile boolean aimApplied;       // Entity.getViewVector diganti arah kamera

    private MixinStatus() {}
}
