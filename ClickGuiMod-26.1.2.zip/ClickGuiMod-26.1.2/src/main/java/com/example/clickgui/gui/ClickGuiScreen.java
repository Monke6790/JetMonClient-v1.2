package com.example.clickgui.gui;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.ModeSetting;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;
import com.example.clickgui.module.util.KeyBinds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Layar utama: daftar kategori + modul. Tap gear (atau klik kanan) pada modul membuka
 * halaman setting modul itu (focus != null): keybind, pilihan, ON/OFF, dan slider.
 */
public class ClickGuiScreen extends Screen {
    // Baris dibuat agak tinggi supaya enak disentuh di layar HP
    private static final int X = 20, Y = 20, ROW_H = 26, CAT_W = 110, GAP = 10, GEAR_W = 22;
    private static Category lastCategory = Category.RENDER; // diingat saat kembali dari halaman setting

    private final Module focus;     // null = daftar modul, non-null = halaman setting modul ini
    private Category selected = lastCategory;
    private NumberSetting dragging; // slider yang sedang digeser
    private Module listening;       // modul yang sedang menunggu tombol keybind
    private String notice = "";     // pesan kecil di bawah
    private int scroll;             // baris pertama yang terlihat

    /** Satu baris di panel: header modul, keybind, aksi, mode, ON/OFF, atau slider. */
    private record Row(Module module, NumberSetting number, BoolSetting bool, ModeSetting mode,
                       boolean action, boolean keybind) {
        boolean isHeader() { return number == null && bool == null && mode == null && !action && !keybind; }
    }

    public ClickGuiScreen() { this(null); }

    public ClickGuiScreen(Module focus) {
        super(Component.literal("JetMonClient"));
        this.focus = focus;
    }

    @Override
    protected void init() {
        if (focus == null) {
            addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(X, height - 30, 80, 20).build());
        } else {
            addRenderableWidget(Button.builder(Component.literal("Back"),
                    b -> Minecraft.getInstance().setScreen(new ClickGuiScreen()))
                .bounds(X, height - 30, 80, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(X + 86, height - 30, 80, 20).build());
        }
    }

    @Override
    public void onClose() {
        ClickGuiMod.MODULES.save();
        super.onClose();
    }

    // ---- layout ----
    private int mx0() { return focus != null ? X : X + CAT_W + GAP; }
    private int modW() { return focus != null ? 270 : 210; }
    private int gearX() { return mx0() + modW() - 8 - font.width("OFF") - 8 - GEAR_W; }
    private int sliderLeft() { return mx0() + 10; }
    private int sliderRight() { return mx0() + modW() - 10; }
    private int upX() { return mx0() + modW() - 46; }
    private int downX() { return mx0() + modW() - 24; }
    private int visibleRows() { return Math.max(3, (height - Y - 22 - 40) / ROW_H); }

    private List<Row> rows() {
        List<Row> out = new ArrayList<>();
        if (focus != null) {
            addModuleRows(out, focus, true);
        } else {
            for (Module m : ClickGuiMod.MODULES.byCategory(selected)) addModuleRows(out, m, false);
        }
        return out;
    }

    private static void addModuleRows(List<Row> out, Module m, boolean withOptions) {
        out.add(new Row(m, null, null, null, false, false));
        if (!withOptions) return;
        out.add(new Row(m, null, null, null, false, true));
        if (m.actionLabel() != null) out.add(new Row(m, null, null, null, true, false));
        for (ModeSetting md : m.modes()) out.add(new Row(m, null, null, md, false, false));
        for (BoolSetting b : m.toggles()) out.add(new Row(m, null, b, null, false, false));
        for (NumberSetting s : m.settings()) out.add(new Row(m, s, null, null, false, false));
    }

    private void updateDrag(double mouseX) {
        if (dragging == null) return;
        dragging.setFraction((mouseX - sliderLeft()) / (double) (sliderRight() - sliderLeft()));
    }

    /** Ikon roda gigi 10x10 piksel, digambar dengan kotak-kotak kecil. */
    private static void drawGear(GuiGraphicsExtractor g, int x, int y, int color, int hole) {
        g.fill(x + 2, y + 2, x + 8, y + 8, color);          // badan
        g.fill(x + 4, y,     x + 6, y + 2, color);          // gigi atas
        g.fill(x + 4, y + 8, x + 6, y + 10, color);         // gigi bawah
        g.fill(x,     y + 4, x + 2, y + 6, color);          // gigi kiri
        g.fill(x + 8, y + 4, x + 10, y + 6, color);         // gigi kanan
        g.fill(x + 1, y + 1, x + 3, y + 3, color);          // gigi diagonal
        g.fill(x + 7, y + 1, x + 9, y + 3, color);
        g.fill(x + 1, y + 7, x + 3, y + 9, color);
        g.fill(x + 7, y + 7, x + 9, y + 9, color);
        g.fill(x + 4, y + 4, x + 6, y + 6, hole);           // lubang tengah
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        // Geser slider: ikuti posisi jari/mouse selama tombol masih ditekan
        if (dragging != null) {
            if (!Minecraft.getInstance().mouseHandler.isLeftPressed()) dragging = null;
            else updateDrag(mouseX);
        }

        super.extractRenderState(g, mouseX, mouseY, partialTick);

        g.text(font, focus == null ? "JetMonClient" : "JetMonClient  >  " + focus.getName() + " settings",
            X, 6, 0xFF55FFFF, true);

        // Panel kategori (hanya di daftar modul)
        if (focus == null) {
            g.fill(X, Y, X + CAT_W, Y + 22 + Category.values().length * ROW_H + 4, 0xCC111111);
            g.text(font, "Categories", X + 4, Y + 7, 0xFFFFD84D, true);
            int i = 0;
            for (Category c : Category.values()) {
                int ry = Y + 22 + i++ * ROW_H;
                g.fill(X + 2, ry, X + CAT_W - 2, ry + ROW_H - 2, c == selected ? 0xFF5B8BC9 : 0xFF222222);
                g.text(font, c.label, X + 8, ry + 9, 0xFFFFFFFF, true);
            }
        }

        // Panel modul / setting
        int mx0 = mx0(), modW = modW();
        List<Row> rows = rows();
        int vis = visibleRows();
        int maxScroll = Math.max(0, rows.size() - vis);
        if (scroll > maxScroll) scroll = maxScroll;
        int shown = Math.min(vis, rows.size() - scroll);

        g.fill(mx0, Y, mx0 + modW, Y + 22 + shown * ROW_H + 4, 0xCC111111);
        g.text(font, focus == null ? selected.label + " Modules" : "Settings", mx0 + 4, Y + 7, 0xFFFFD84D, true);
        if (rows.size() > vis) {
            g.fill(upX(), Y + 3, upX() + 18, Y + 19, scroll > 0 ? 0xFF3A3A3A : 0xFF222222);
            g.fill(downX(), Y + 3, downX() + 18, Y + 19, scroll < maxScroll ? 0xFF3A3A3A : 0xFF222222);
            g.text(font, "^", upX() + (18 - font.width("^")) / 2, Y + 7, 0xFFFFFFFF, true);
            g.text(font, "v", downX() + (18 - font.width("v")) / 2, Y + 7, 0xFFFFFFFF, true);
        }

        for (int k = scroll; k < scroll + shown; k++) {
            Row r = rows.get(k);
            int ry = Y + 22 + (k - scroll) * ROW_H;
            if (r.isHeader()) {
                Module m = r.module();
                g.fill(mx0 + 2, ry, mx0 + modW - 2, ry + ROW_H - 2, 0xFF2A2A2A);
                g.text(font, m.getName(), mx0 + 8, ry + 9, 0xFFFFFFFF, true);
                String st = m.isEnabled() ? "ON" : "OFF";
                g.text(font, st, mx0 + modW - 8 - font.width(st), ry + 9,
                    m.isEnabled() ? 0xFF55FF55 : 0xFFFF5555, true);
                if (focus == null) {
                    // Tombol gear di samping ON/OFF: membuka halaman setting
                    int gx = gearX();
                    g.fill(gx, ry + 2, gx + GEAR_W, ry + ROW_H - 4, 0xFF3A3A3A);
                    drawGear(g, gx + (GEAR_W - 10) / 2, ry + (ROW_H - 2 - 10) / 2, 0xFFFFFFFF, 0xFF3A3A3A);
                }
            } else if (r.keybind()) {
                Module m = r.module();
                g.fill(mx0 + 2, ry, mx0 + modW - 2, ry + ROW_H - 2, 0xFF2B2338);
                g.text(font, "  Keybind", mx0 + 8, ry + 9, 0xFFCCCCCC, true);
                boolean wait = listening == m;
                String label = wait ? "Press a key..." : KeyBinds.name(m.keyMapping());
                g.text(font, label, mx0 + modW - 8 - font.width(label), ry + 9,
                    wait ? 0xFFFFFF55 : 0xFF55FFFF, true);
            } else if (r.action()) {
                g.fill(mx0 + 2, ry, mx0 + modW - 2, ry + ROW_H - 2, 0xFF1F3A4D);
                g.text(font, "  " + r.module().actionLabel(), mx0 + 8, ry + 9, 0xFFFFFFFF, true);
                g.text(font, ">", mx0 + modW - 10 - font.width(">"), ry + 9, 0xFFFFFFFF, true);
            } else if (r.mode() != null) {
                ModeSetting md = r.mode();
                g.fill(mx0 + 2, ry, mx0 + modW - 2, ry + ROW_H - 2, 0xFF1C1C1C);
                g.text(font, "  " + md.getName(), mx0 + 8, ry + 9, 0xFFCCCCCC, true);
                g.text(font, md.get(), mx0 + modW - 8 - font.width(md.get()), ry + 9, 0xFF55FFFF, true);
            } else if (r.bool() != null) {
                BoolSetting b = r.bool();
                g.fill(mx0 + 2, ry, mx0 + modW - 2, ry + ROW_H - 2, 0xFF1C1C1C);
                g.text(font, "  " + b.getName(), mx0 + 8, ry + 9, 0xFFCCCCCC, true);
                String st = b.get() ? "ON" : "OFF";
                g.text(font, st, mx0 + modW - 8 - font.width(st), ry + 9,
                    b.get() ? 0xFF55FF55 : 0xFFFF5555, true);
            } else {
                // Slider: label + nilai di atas, batang geser di bawah
                NumberSetting s = r.number();
                g.fill(mx0 + 2, ry, mx0 + modW - 2, ry + ROW_H - 2, 0xFF1C1C1C);
                g.text(font, "  " + s.getName() + ": " + s.display(), mx0 + 8, ry + 3, 0xFFCCCCCC, true);
                int bx0 = sliderLeft(), bx1 = sliderRight(), by = ry + 16;
                int fillX = bx0 + (int) ((bx1 - bx0) * s.fraction());
                g.fill(bx0, by, bx1, by + 4, 0xFF3A3A3A);
                g.fill(bx0, by, fillX, by + 4, 0xFF5B8BC9);
                g.fill(fillX - 2, by - 2, fillX + 2, by + 6, s == dragging ? 0xFF55FFFF : 0xFFFFFFFF);
            }
        }
        String hint = focus == null ? "Tap gear for module settings" : "Drag sliders, tap rows to change";
        g.text(font, notice.isEmpty() ? hint : notice, X + (focus == null ? 90 : 176), height - 24,
            notice.isEmpty() ? 0xFF999999 : 0xFFFFAA55, true);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true; // tombol Close / Back

        double mx = event.x(), my = event.y();
        int button = event.button(); // 0 = kiri, 1 = kanan
        notice = "";

        if (focus == null) {
            int i = 0;
            for (Category c : Category.values()) {
                int ry = Y + 22 + i++ * ROW_H;
                if (mx >= X + 2 && mx <= X + CAT_W - 2 && my >= ry && my <= ry + ROW_H - 2) {
                    selected = c;
                    lastCategory = c;
                    scroll = 0;
                    listening = null;
                    return true;
                }
            }
        }

        int mx0 = mx0(), modW = modW();
        List<Row> rows = rows();
        int vis = visibleRows();
        int maxScroll = Math.max(0, rows.size() - vis);
        int shown = Math.min(vis, rows.size() - Math.min(scroll, maxScroll));

        // Tombol panah scroll
        if (rows.size() > vis && my >= Y + 3 && my <= Y + 19) {
            if (mx >= upX() && mx <= upX() + 18) { scroll = Math.max(0, scroll - 2); return true; }
            if (mx >= downX() && mx <= downX() + 18) { scroll = Math.min(maxScroll, scroll + 2); return true; }
        }

        for (int k = scroll; k < scroll + shown; k++) {
            int ry = Y + 22 + (k - scroll) * ROW_H;
            if (mx < mx0 + 2 || mx > mx0 + modW - 2 || my < ry || my > ry + ROW_H - 2) continue;
            Row r = rows.get(k);
            if (r.isHeader()) {
                Module m = r.module();
                int gx = gearX();
                boolean onGear = focus == null && mx >= gx && mx <= gx + GEAR_W;
                if (focus == null && (button == 1 || onGear)) {
                    // klik kanan atau tap gear: buka halaman setting modul
                    Minecraft.getInstance().setScreen(new ClickGuiScreen(m));
                } else if (button == 0) {
                    m.toggle();
                    ClickGuiMod.MODULES.save();
                }
            } else if (r.keybind()) {
                Module m = r.module();
                if (listening == m) {
                    // tap lagi saat menunggu = hapus keybind
                    if (!KeyBinds.bind(m.keyMapping(), GLFW.GLFW_KEY_UNKNOWN)) notice = "Set keybind di Options > Controls";
                    listening = null;
                } else {
                    listening = m;
                }
            } else if (r.action()) {
                r.module().runAction(this);
            } else if (r.mode() != null) {
                r.mode().cycle();
            } else if (r.bool() != null) {
                r.bool().toggle();
            } else {
                // mulai geser slider
                dragging = r.number();
                updateDrag(mx);
            }
            return true;
        }
        return false;
    }

    /** Roda mouse: gulir panel (tanpa @Override agar aman jika signature berbeda). */
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        scroll = Math.max(0, scroll - (int) Math.signum(scrollY));
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        // Sedang menunggu tombol untuk keybind: Esc = hapus, tombol lain = pasang
        if (listening != null) {
            int code = event.key();
            if (code == GLFW.GLFW_KEY_ESCAPE) code = GLFW.GLFW_KEY_UNKNOWN;
            if (!KeyBinds.bind(listening.keyMapping(), code)) notice = "Set keybind di Options > Controls";
            listening = null;
            return true;
        }
        if (event.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
