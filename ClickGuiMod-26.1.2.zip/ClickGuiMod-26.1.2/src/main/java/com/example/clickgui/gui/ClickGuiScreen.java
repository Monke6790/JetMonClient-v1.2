package com.example.clickgui.gui;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    // Baris dibuat agak tinggi supaya enak disentuh di layar HP
    private static final int X = 20, Y = 20, ROW_H = 26, CAT_W = 110, MOD_W = 200, GAP = 10, BTN_W = 22;
    private Category selected = Category.RENDER;

    private record Row(Module module, NumberSetting setting) {}

    public ClickGuiScreen() { super(Component.literal("ClickGUI")); }

    @Override
    protected void init() {
        // Tombol Close untuk perangkat tanpa keyboard
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
            .bounds(X, height - 30, 80, 20).build());
    }

    private List<Row> rows() {
        List<Row> out = new ArrayList<>();
        for (Module m : ClickGuiMod.MODULES.byCategory(selected)) {
            out.add(new Row(m, null));
            for (NumberSetting s : m.settings()) out.add(new Row(m, s));
        }
        return out;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);

        // Panel kategori
        g.fill(X, Y, X + CAT_W, Y + 22 + Category.values().length * ROW_H + 4, 0xCC111111);
        g.text(font, "Categories", X + 4, Y + 7, 0xFFFFD84D, true);
        int i = 0;
        for (Category c : Category.values()) {
            int ry = Y + 22 + i++ * ROW_H;
            g.fill(X + 2, ry, X + CAT_W - 2, ry + ROW_H - 2, c == selected ? 0xFF5B8BC9 : 0xFF222222);
            g.text(font, c.label, X + 8, ry + 9, 0xFFFFFFFF, true);
        }

        // Panel modul + setting
        int mx0 = X + CAT_W + GAP;
        List<Row> rows = rows();
        g.fill(mx0, Y, mx0 + MOD_W, Y + 22 + rows.size() * ROW_H + 4, 0xCC111111);
        g.text(font, selected.label + " Modules", mx0 + 4, Y + 7, 0xFFFFD84D, true);
        for (int k = 0; k < rows.size(); k++) {
            Row r = rows.get(k);
            int ry = Y + 22 + k * ROW_H;
            if (r.setting() == null) {
                Module m = r.module();
                g.fill(mx0 + 2, ry, mx0 + MOD_W - 2, ry + ROW_H - 2, 0xFF2A2A2A);
                g.text(font, m.getName(), mx0 + 8, ry + 9, 0xFFFFFFFF, true);
                String st = m.isEnabled() ? "ON" : "OFF";
                g.text(font, st, mx0 + MOD_W - 8 - font.width(st), ry + 9,
                    m.isEnabled() ? 0xFF55FF55 : 0xFFFF5555, true);
            } else {
                NumberSetting s = r.setting();
                g.fill(mx0 + 2, ry, mx0 + MOD_W - 2, ry + ROW_H - 2, 0xFF1C1C1C);
                g.text(font, "  " + s.getName() + ": " + s.display(), mx0 + 8, ry + 9, 0xFFCCCCCC, true);
                int minusX = mx0 + MOD_W - 4 - BTN_W * 2 - 2;
                int plusX = mx0 + MOD_W - 4 - BTN_W;
                g.fill(minusX, ry + 2, minusX + BTN_W, ry + ROW_H - 4, 0xFF3A3A3A);
                g.fill(plusX, ry + 2, plusX + BTN_W, ry + ROW_H - 4, 0xFF3A3A3A);
                g.text(font, "-", minusX + (BTN_W - font.width("-")) / 2, ry + 9, 0xFFFFFFFF, true);
                g.text(font, "+", plusX + (BTN_W - font.width("+")) / 2, ry + 9, 0xFFFFFFFF, true);
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true; // tombol Close

        double mx = event.x(), my = event.y();
        int i = 0;
        for (Category c : Category.values()) {
            int ry = Y + 22 + i++ * ROW_H;
            if (mx >= X + 2 && mx <= X + CAT_W - 2 && my >= ry && my <= ry + ROW_H - 2) {
                selected = c;
                return true;
            }
        }

        int mx0 = X + CAT_W + GAP;
        List<Row> rows = rows();
        for (int k = 0; k < rows.size(); k++) {
            int ry = Y + 22 + k * ROW_H;
            if (mx < mx0 + 2 || mx > mx0 + MOD_W - 2 || my < ry || my > ry + ROW_H - 2) continue;
            Row r = rows.get(k);
            if (r.setting() == null) {
                r.module().toggle();
            } else {
                int minusX = mx0 + MOD_W - 4 - BTN_W * 2 - 2;
                int plusX = mx0 + MOD_W - 4 - BTN_W;
                if (mx >= minusX && mx <= minusX + BTN_W) r.setting().dec();
                else if (mx >= plusX && mx <= plusX + BTN_W) r.setting().inc();
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
