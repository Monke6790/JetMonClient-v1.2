package com.example.clickgui.gui;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClickGuiScreen extends Screen {
    // Baris dibuat agak tinggi supaya enak disentuh di layar HP
    private static final int X = 20, Y = 20, ROW_H = 26, CAT_W = 110, MOD_W = 210, GAP = 10, GEAR_W = 20;
    private static final int MX0 = X + CAT_W + GAP;
    private static final Set<Module> EXPANDED = new HashSet<>(); // diingat antar pembukaan GUI
    private Category selected = Category.RENDER;
    private NumberSetting dragging; // slider yang sedang digeser

    /** Satu baris di panel: header modul, slider angka, baris ON/OFF, atau baris aksi. */
    private record Row(Module module, NumberSetting number, BoolSetting bool, boolean action) {
        boolean isHeader() { return number == null && bool == null && !action; }
    }

    public ClickGuiScreen() { super(Component.literal("JetMonClient")); }

    @Override
    protected void init() {
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
            .bounds(X, height - 30, 80, 20).build());
    }

    private List<Row> rows() {
        List<Row> out = new ArrayList<>();
        for (Module m : ClickGuiMod.MODULES.byCategory(selected)) {
            out.add(new Row(m, null, null, false));
            if (EXPANDED.contains(m)) {
                if (m.actionLabel() != null) out.add(new Row(m, null, null, true));
                for (BoolSetting b : m.toggles()) out.add(new Row(m, null, b, false));
                for (NumberSetting s : m.settings()) out.add(new Row(m, s, null, false));
            }
        }
        return out;
    }

    private int gearX() {
        return MX0 + MOD_W - 8 - font.width("OFF") - 8 - GEAR_W;
    }

    private static int sliderLeft() { return MX0 + 10; }
    private static int sliderRight() { return MX0 + MOD_W - 10; }

    private void updateDrag(double mouseX) {
        if (dragging == null) return;
        dragging.setFraction((mouseX - sliderLeft()) / (double) (sliderRight() - sliderLeft()));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        // Geser slider: ikuti posisi jari/mouse selama tombol masih ditekan
        if (dragging != null) {
            if (!Minecraft.getInstance().mouseHandler.isLeftPressed()) dragging = null;
            else updateDrag(mouseX);
        }

        super.extractRenderState(g, mouseX, mouseY, partialTick);

        g.text(font, "JetMonClient", X, 6, 0xFF55FFFF, true);

        // Panel kategori
        g.fill(X, Y, X + CAT_W, Y + 22 + Category.values().length * ROW_H + 4, 0xCC111111);
        g.text(font, "Categories", X + 4, Y + 7, 0xFFFFD84D, true);
        int i = 0;
        for (Category c : Category.values()) {
            int ry = Y + 22 + i++ * ROW_H;
            g.fill(X + 2, ry, X + CAT_W - 2, ry + ROW_H - 2, c == selected ? 0xFF5B8BC9 : 0xFF222222);
            g.text(font, c.label, X + 8, ry + 9, 0xFFFFFFFF, true);
        }

        // Panel modul + setting
        List<Row> rows = rows();
        g.fill(MX0, Y, MX0 + MOD_W, Y + 22 + rows.size() * ROW_H + 4, 0xCC111111);
        g.text(font, selected.label + " Modules", MX0 + 4, Y + 7, 0xFFFFD84D, true);
        for (int k = 0; k < rows.size(); k++) {
            Row r = rows.get(k);
            int ry = Y + 22 + k * ROW_H;
            if (r.isHeader()) {
                Module m = r.module();
                g.fill(MX0 + 2, ry, MX0 + MOD_W - 2, ry + ROW_H - 2, 0xFF2A2A2A);
                g.text(font, m.getName(), MX0 + 8, ry + 9, 0xFFFFFFFF, true);
                String st = m.isEnabled() ? "ON" : "OFF";
                g.text(font, st, MX0 + MOD_W - 8 - font.width(st), ry + 9,
                    m.isEnabled() ? 0xFF55FF55 : 0xFFFF5555, true);
                if (m.hasOptions()) {
                    int gx = gearX();
                    boolean open = EXPANDED.contains(m);
                    g.fill(gx, ry + 2, gx + GEAR_W, ry + ROW_H - 4, open ? 0xFF5B8BC9 : 0xFF3A3A3A);
                    String arrow = open ? "v" : ">";
                    g.text(font, arrow, gx + (GEAR_W - font.width(arrow)) / 2, ry + 9, 0xFFFFFFFF, true);
                }
            } else if (r.action()) {
                g.fill(MX0 + 2, ry, MX0 + MOD_W - 2, ry + ROW_H - 2, 0xFF1F3A4D);
                g.text(font, "  " + r.module().actionLabel(), MX0 + 8, ry + 9, 0xFFFFFFFF, true);
                g.text(font, ">", MX0 + MOD_W - 10 - font.width(">"), ry + 9, 0xFFFFFFFF, true);
            } else if (r.bool() != null) {
                BoolSetting b = r.bool();
                g.fill(MX0 + 2, ry, MX0 + MOD_W - 2, ry + ROW_H - 2, 0xFF1C1C1C);
                g.text(font, "  " + b.getName(), MX0 + 8, ry + 9, 0xFFCCCCCC, true);
                String st = b.get() ? "ON" : "OFF";
                g.text(font, st, MX0 + MOD_W - 8 - font.width(st), ry + 9,
                    b.get() ? 0xFF55FF55 : 0xFFFF5555, true);
            } else {
                // Slider: label + nilai di atas, batang geser di bawah
                NumberSetting s = r.number();
                g.fill(MX0 + 2, ry, MX0 + MOD_W - 2, ry + ROW_H - 2, 0xFF1C1C1C);
                g.text(font, "  " + s.getName() + ": " + s.display(), MX0 + 8, ry + 3, 0xFFCCCCCC, true);
                int bx0 = sliderLeft(), bx1 = sliderRight(), by = ry + 16;
                int fillX = bx0 + (int) ((bx1 - bx0) * s.fraction());
                g.fill(bx0, by, bx1, by + 4, 0xFF3A3A3A);
                g.fill(bx0, by, fillX, by + 4, 0xFF5B8BC9);
                g.fill(fillX - 2, by - 2, fillX + 2, by + 6, s == dragging ? 0xFF55FFFF : 0xFFFFFFFF);
            }
        }
        g.text(font, "Right-click / tap > for settings, drag sliders", X + 90, height - 24, 0xFF999999, true);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true; // tombol Close

        double mx = event.x(), my = event.y();
        int button = event.button(); // 0 = kiri, 1 = kanan

        int i = 0;
        for (Category c : Category.values()) {
            int ry = Y + 22 + i++ * ROW_H;
            if (mx >= X + 2 && mx <= X + CAT_W - 2 && my >= ry && my <= ry + ROW_H - 2) {
                selected = c;
                return true;
            }
        }

        List<Row> rows = rows();
        for (int k = 0; k < rows.size(); k++) {
            int ry = Y + 22 + k * ROW_H;
            if (mx < MX0 + 2 || mx > MX0 + MOD_W - 2 || my < ry || my > ry + ROW_H - 2) continue;
            Row r = rows.get(k);
            if (r.isHeader()) {
                Module m = r.module();
                int gx = gearX();
                boolean onGear = m.hasOptions() && mx >= gx && mx <= gx + GEAR_W;
                if (button == 1 || onGear) {
                    // klik kanan atau tap tombol > : buka/tutup setting
                    if (m.hasOptions() && !EXPANDED.remove(m)) EXPANDED.add(m);
                } else if (button == 0) {
                    m.toggle();
                }
            } else if (r.action()) {
                r.module().runAction(this);
            } else if (r.bool() != null) {
                r.bool().toggle();
            } else {
                // mulai geser slider
                dragging = r.number();
                updateDrag(mx);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        return super.keyPressed(event);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
