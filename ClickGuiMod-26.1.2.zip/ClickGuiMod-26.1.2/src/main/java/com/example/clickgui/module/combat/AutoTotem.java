package com.example.clickgui.module.combat;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Items;

/** Menjaga totem tetap ada di tangan kiri (totem harus ada di hotbar). */
public class AutoTotem extends CombatModule {
    private int prevSlot = -1;
    private int cooldown;

    public AutoTotem() { super("AutoTotem"); }

    @Override
    protected void combatTick() {
        if (cooldown > 0) { cooldown--; return; }
        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) { prevSlot = -1; return; }

        Inventory inv = mc.player.getInventory();
        boolean inHotbar = false;
        for (int i = 0; i < 9; i++) {
            if (inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) { inHotbar = true; break; }
        }
        if (!inHotbar || mc.getConnection() == null) { prevSlot = -1; return; }

        // Tick 1: pilih slot totem. Tick 2: tukar ke tangan kiri lalu kembalikan slot.
        if (!mc.player.getMainHandItem().is(Items.TOTEM_OF_UNDYING)) {
            if (prevSlot < 0) prevSlot = inv.getSelectedSlot();
            holding(s -> s.is(Items.TOTEM_OF_UNDYING));
            return;
        }
        mc.getConnection().send(new ServerboundPlayerActionPacket(
            ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ZERO, Direction.DOWN));
        if (prevSlot >= 0) {
            inv.setSelectedSlot(prevSlot);
            prevSlot = -1;
        }
        cooldown = 6; // tunggu respons server supaya tidak tertukar balik
    }
}
