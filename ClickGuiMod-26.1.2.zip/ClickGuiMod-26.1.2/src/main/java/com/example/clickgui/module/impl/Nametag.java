package com.example.clickgui.module.impl;

import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Nametag bergaya Meteor: label nama + HP + jarak digambar di layar (tembus tembok)
 * untuk pemain dan mob. Posisi layar dihitung manual dari kamera, jadi hanya aktif
 * di first person (efek FOV saat sprint bisa membuat posisinya sedikit bergeser).
 */
public class Nametag extends Module {
    private static final double MAX_DISTANCE = 96.0;

    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Mobs", true);
    private final BoolSetting health = bool("Health", true);
    private final BoolSetting distance = bool("Distance", true);
    private final BoolSetting background = bool("Background", true);

    public Nametag() { super("Nametag", Category.RENDER); }

    @Override
    public void renderHud(GuiGraphicsExtractor g, float pt) {
        Entity cam = mc.getCameraEntity();
        if (cam == null || mc.level == null || mc.player == null) return;
        if (!mc.options.getCameraType().isFirstPerson()) return;

        // Basis kamera dari yaw/pitch
        Vec3 camPos = cam.getEyePosition(pt);
        double yaw = Math.toRadians(cam.getViewYRot(pt));
        double pitch = Math.toRadians(cam.getViewXRot(pt));
        Vec3 forward = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3 up = right.cross(forward);

        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        double tanY = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        double tanX = tanY * sw / (double) sh;

        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || e == cam || e instanceof ArmorStand) continue;
            boolean isPlayer = e instanceof Player;
            if (isPlayer ? !players.get() : !mobs.get()) continue;

            double dist = camPos.distanceTo(e.position());
            if (dist > MAX_DISTANCE) continue;

            // Titik sedikit di atas kepala (di atas nametag bawaan)
            Vec3 v = e.getPosition(pt).add(0, e.getBbHeight() + 0.9, 0).subtract(camPos);
            double z = v.dot(forward);
            if (z < 0.1) continue; // di belakang kamera
            double x = v.dot(right), y = v.dot(up);
            int sx = (int) (sw / 2.0 + (x / z) / tanX * (sw / 2.0));
            int sy = (int) (sh / 2.0 - (y / z) / tanY * (sh / 2.0));

            String name = e.getName().getString();
            String hp = "";
            int hpColor = 0xFF55FF55;
            if (health.get()) {
                float h = le.getHealth(), max = Math.max(1f, le.getMaxHealth());
                hp = " " + (int) Math.ceil(h) + "hp";
                float ratio = h / max;
                hpColor = ratio > 0.66f ? 0xFF55FF55 : ratio > 0.33f ? 0xFFFFFF55 : 0xFFFF5555;
            }
            String dst = distance.get() ? " " + (int) dist + "m" : "";

            int total = mc.font.width(name) + mc.font.width(hp) + mc.font.width(dst);
            int x0 = sx - total / 2;
            if (background.get()) g.fill(x0 - 2, sy - 2, x0 + total + 2, sy + 10, 0x90000000);

            g.text(mc.font, name, x0, sy, isPlayer ? 0xFFFFFFFF : 0xFFFFC0A0, true);
            int cx = x0 + mc.font.width(name);
            if (!hp.isEmpty()) {
                g.text(mc.font, hp, cx, sy, hpColor, true);
                cx += mc.font.width(hp);
            }
            if (!dst.isEmpty()) g.text(mc.font, dst, cx, sy, 0xFFAAAAAA, true);
        }
    }
}
