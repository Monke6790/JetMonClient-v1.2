package com.example.clickgui.module.impl;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Map;

/**
 * Menampilkan nama + HP di atas mob (client-side) lewat mekanisme custom name bawaan.
 * Pemain sudah punya nametag bawaan, jadi dilewati.
 */
public class Nametag extends Module {
    private record Saved(Component name, boolean visible) {}
    private final Map<Integer, Saved> saved = new HashMap<>();
    private final Map<Integer, Integer> lastHp = new HashMap<>();

    public Nametag() { super("Nametag", Category.RENDER); }

    @Override
    public void onTick() {
        if (mc.level == null || mc.player == null) return;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || e instanceof Player || e instanceof ArmorStand) continue;
            if (mc.player.distanceTo(e) > 64) continue;

            int id = e.getId();
            Saved s = saved.computeIfAbsent(id, k -> new Saved(e.getCustomName(), e.isCustomNameVisible()));
            int hp = (int) Math.ceil(le.getHealth());
            if (lastHp.getOrDefault(id, -1) != hp || !e.isCustomNameVisible()) {
                String base = s.name() != null ? s.name().getString() : e.getType().getDescription().getString();
                e.setCustomName(Component.literal(base + " [" + hp + "/" + (int) le.getMaxHealth() + "]"));
                e.setCustomNameVisible(true);
                lastHp.put(id, hp);
            }
        }
    }

    @Override
    protected void onDisable() {
        if (mc.level != null) {
            for (Map.Entry<Integer, Saved> en : saved.entrySet()) {
                Entity e = mc.level.getEntity(en.getKey());
                if (e == null) continue;
                e.setCustomName(en.getValue().name());
                e.setCustomNameVisible(en.getValue().visible());
            }
        }
        saved.clear();
        lastHp.clear();
    }
}
