package com.example.clickgui.render;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Kumpulan bentuk yang dikumpulkan saat fase extraction, digambar saat fase drawing. */
public class WorldShapes {
    public record BoxShape(AABB box, float r, float g, float b, float fillAlpha, float outlineAlpha) {}
    public record LineShape(Vec3 from, Vec3 to, float r, float g, float b, float a, float thickness) {}

    public final List<BoxShape> boxes = new ArrayList<>();
    public final List<LineShape> lines = new ArrayList<>();

    public void box(AABB box, float[] rgb, float fillAlpha, float outlineAlpha) {
        boxes.add(new BoxShape(box, rgb[0], rgb[1], rgb[2], fillAlpha, outlineAlpha));
    }

    public void line(Vec3 from, Vec3 to, float[] rgb, float alpha) {
        line(from, to, rgb, alpha, 1.0f);
    }

    /** thickness 1.0 = sekitar 1 piksel di layar, berapa pun jaraknya. */
    public void line(Vec3 from, Vec3 to, float[] rgb, float alpha, float thickness) {
        lines.add(new LineShape(from, to, rgb[0], rgb[1], rgb[2], alpha, thickness));
    }

    public boolean isEmpty() { return boxes.isEmpty() && lines.isEmpty(); }
}
