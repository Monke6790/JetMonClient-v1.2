package com.example.clickgui.module.impl;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;

public class AutoSprint extends Module {
    public AutoSprint() { super("AutoSprint", Category.MOVEMENT); }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.options.keyUp.isDown() && !mc.player.horizontalCollision) {
            mc.player.setSprinting(true);
        }
    }
}
