package com.example.clickgui.module.impl;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public class CoordsHud extends Module {
    public CoordsHud() { super("Coords", Category.MISC); }

    @Override
    public void renderHud(GuiGraphicsExtractor g, float pt) {
        if (mc.player == null) return;
        String text = String.format("XYZ: %.1f / %.1f / %.1f",
            mc.player.getX(), mc.player.getY(), mc.player.getZ());
        g.text(mc.font, text, 4, 4, 0xFFFFFF55, true);
    }
}
