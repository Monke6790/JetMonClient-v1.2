package com.example.clickgui.module;

import com.example.clickgui.config.Config;
import com.example.clickgui.module.combat.*;
import com.example.clickgui.module.impl.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    public final Freecam freecam = new Freecam();

    public ModuleManager() {
        // Render
        modules.add(new PlayerEsp());
        modules.add(new Tracer());
        modules.add(new StorageEsp());
        modules.add(new BlockEsp());
        modules.add(new Nametag());
        modules.add(new Fullbright());
        // Combat (hanya aktif di world single-player)
        modules.add(new AutoTotem());
        modules.add(new AutoCrystal());
        modules.add(new AnchorMacro());
        modules.add(new AutoShield());
        modules.add(new AutoAttack());
        // Movement
        modules.add(new AutoSprint());
        // Misc
        modules.add(new CoordsHud());
        modules.add(freecam);
        modules.add(new Freelook());
        modules.add(new Zoom());
    }

    public List<Module> all() { return modules; }

    public List<Module> byCategory(Category c) {
        return modules.stream().filter(m -> m.getCategory() == c).toList();
    }

    public void preTick() {
        for (Module m : modules) if (m.isEnabled()) m.onPreTick();
    }

    public void tick() {
        for (Module m : modules) if (m.isEnabled()) m.onTick();
    }

    /** Dipanggil saat game ditutup supaya pengaturan (mis. FOV) dikembalikan. */
    public void disableAll() {
        for (Module m : modules) if (m.isEnabled()) m.setEnabled(false);
    }

    public void save() { Config.save(this); }
    public void load() { Config.load(this); }

    /** Pemain masuk dunia/server baru: modul yang masih ON dinyalakan ulang agar bekerja di dunia itu. */
    public void onWorldChanged() {
        for (Module m : modules) if (m.isEnabled()) m.onWorldChanged();
    }
}
