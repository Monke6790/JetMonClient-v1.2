package com.example.clickgui.module.impl;

import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.ModeSetting;
import com.example.clickgui.module.NumberSetting;
import com.example.clickgui.module.util.EntityUtil;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Garis tipis dari crosshair ke pemain. Opsi mirip Tracers Meteor: target Head/Body/Feet, warna jarak. */
public class Tracer extends Module {
    private final ModeSetting target = mode("Target", "Body", "Head", "Body", "Feet");
    private final BoolSetting invisible = bool("Invisible", true);
    private final BoolSetting distanceColors = bool("Distance colors", false);
    private final NumberSetting thickness = number("Thickness", 0.5, 5, 0.5, 1);

    public Tracer() { super("Tracer", Category.RENDER); }

    @Override
    public void extract(WorldShapes shapes, float pt) {
        Vec3 start = EntityUtil.tracerStart(pt);
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof Player) || !EntityUtil.isTarget(e)) continue;
            if (!invisible.get() && e.isInvisible()) continue;

            AABB box = EntityUtil.box(e, pt);
            Vec3 c = box.getCenter();
            Vec3 end = switch (target.get()) {
                case "Head" -> new Vec3(c.x, box.minY + e.getEyeHeight(), c.z);
                case "Feet" -> new Vec3(c.x, box.minY, c.z);
                default -> c;
            };
            float[] color = distanceColors.get()
                ? EntityUtil.distanceColor(mc.player.distanceTo(e))
                : EntityUtil.color(e);
            shapes.line(start, end, color, 0.9f, (float) thickness.get());
        }
    }
}
