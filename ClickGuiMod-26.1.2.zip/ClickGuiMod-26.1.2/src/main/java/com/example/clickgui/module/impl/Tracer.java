package com.example.clickgui.module.impl;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.util.EntityUtil;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class Tracer extends Module {
    public Tracer() { super("Tracer", Category.RENDER); }

    @Override
    public void extract(WorldShapes shapes, float pt) {
        // Titik awal sedikit di depan kamera supaya tidak terpotong near-plane
        Vec3 start = mc.player.getEyePosition(pt).add(mc.player.getViewVector(pt).scale(1.0));
        for (Entity e : mc.level.entitiesForRendering()) {
            // Hanya pemain, mob tidak diberi tracer
            if (!(e instanceof Player) || !EntityUtil.isTarget(e) || mc.player.distanceTo(e) > 128) continue;
            Vec3 end = EntityUtil.box(e, pt).getCenter();
            shapes.line(start, end, EntityUtil.color(e), 0.9f);
        }
    }
}
