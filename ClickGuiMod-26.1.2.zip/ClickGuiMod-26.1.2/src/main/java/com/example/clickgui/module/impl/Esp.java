package com.example.clickgui.module.impl;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;

import com.example.clickgui.module.util.EntityUtil;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.world.entity.Entity;

public class Esp extends Module {
    private final NumberSetting range = number("Range", 16, 256, 16, 128);

    public Esp() { super("ESP", Category.RENDER); }

    @Override
    public void extract(WorldShapes shapes, float pt) {
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!EntityUtil.isTarget(e) || mc.player.distanceTo(e) > range.get()) continue;
            shapes.box(EntityUtil.box(e, pt), EntityUtil.color(e), 0.22f, 0.95f);
        }
    }
}
