package com.example.clickgui.module;

/** Pengaturan angka. Di ClickGUI diubah dengan menggeser slider. */
public class NumberSetting {
    private final String name;
    private final double min, max, step;
    private double value;

    public NumberSetting(String name, double min, double max, double step, double def) {
        this.name = name;
        this.min = min;
        this.max = max;
        this.step = step;
        this.value = def;
    }

    public String getName() { return name; }
    public double get() { return value; }

    public void set(double v) {
        double snapped = Math.round(v / step) * step;
        value = Math.max(min, Math.min(max, Math.round(snapped * 10000.0) / 10000.0));
    }

    /** Posisi nilai di slider, 0.0 sampai 1.0. */
    public double fraction() { return (value - min) / (max - min); }

    /** Atur nilai dari posisi slider (0.0 sampai 1.0), otomatis dibulatkan ke step. */
    public void setFraction(double f) {
        f = Math.max(0.0, Math.min(1.0, f));
        set(min + f * (max - min));
    }

    public String display() {
        return step >= 1 ? String.format("%.0f", value) : String.format("%.1f", value);
    }
}
