package com.example.clickgui.module;

/** Pengaturan angka yang bisa diubah dengan tombol - dan + di ClickGUI. */
public class NumberSetting {
    private final String name;
    private final double min, max, step;
    private double value;

    public NumberSetting(String name, double min, double max, double step, double def) {
        this.name = name;
        this.min = min;
        this.max = max;
        this.step = step;
        this.value = def;
    }

    public String getName() { return name; }
    public double get() { return value; }

    public void set(double v) {
        double snapped = Math.round(v / step) * step;
        value = Math.max(min, Math.min(max, Math.round(snapped * 10000.0) / 10000.0));
    }

    public void inc() { set(value + step); }
    public void dec() { set(value - step); }

    public String display() {
        return step >= 1 ? String.format("%.0f", value) : String.format("%.1f", value);
    }
}
