package com.example.clickgui.mixin;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.impl.Freecam;
import com.example.clickgui.module.impl.Freelook;
import com.example.clickgui.module.util.ViewState;
import com.example.clickgui.util.MixinStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Untuk pemain lokal saat Freecam / Freelook aktif:
 *  - turn: gerakan mouse/sentuhan memutar kamera modul, bukan pemain (faktor 0.15 seperti bawaan).
 *  - getViewVector: arah bidik = arah kamera, jadi blok yang disorot dan digali adalah blok di
 *    tengah layar (sorotan, menggali, memasang blok, dan menyerang memakai arah yang sama).
 *  - getEyePosition(float): saat Freecam, titik bidik = posisi kamera.
 * Semua injeksi memakai require = 0: jika target tidak ada, dilewati tanpa crash.
 */
@Mixin(Entity.class)
public abstract class EntityMixin {

    @Inject(method = "turn", at = @At("HEAD"), cancellable = true, require = 0)
    private void jetmon$turn(double yRot, double xRot, CallbackInfo ci) {
        if ((Object) this != Minecraft.getInstance().player) return;
        MixinStatus.turnSeen = true;

        Freecam fc = ClickGuiMod.MODULES.freecam;
        if (fc.isEnabled() && fc.cameraReady()) {
            fc.updateRotation(yRot * 0.15, xRot * 0.15);
            ci.cancel();
            return;
        }
        Freelook fl = ClickGuiMod.MODULES.freelook;
        if (fl.isEnabled() && fl.cameraReady()) {
            fl.updateRotation(yRot * 0.15, xRot * 0.15);
            ci.cancel();
        }
    }

    @Inject(method = "getViewVector(F)Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"),
        cancellable = true, require = 0)
    private void jetmon$viewVector(float partialTicks, CallbackInfoReturnable<Vec3> cir) {
        if ((Object) this != Minecraft.getInstance().player) return;

        Freecam fc = ClickGuiMod.MODULES.freecam;
        if (fc.isEnabled() && fc.cameraReady()) {
            MixinStatus.aimApplied = true;
            cir.setReturnValue(ViewState.directionOf(fc.yaw(), fc.pitch()));
            return;
        }
        Freelook fl = ClickGuiMod.MODULES.freelook;
        if (fl.isEnabled() && fl.cameraReady()) {
            MixinStatus.aimApplied = true;
            cir.setReturnValue(ViewState.directionOf(fl.yaw(), fl.pitch()));
        }
    }

    @Inject(method = "getEyePosition(F)Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"),
        cancellable = true, require = 0)
    private void jetmon$eyePosition(float partialTicks, CallbackInfoReturnable<Vec3> cir) {
        if ((Object) this != Minecraft.getInstance().player) return;

        Freecam fc = ClickGuiMod.MODULES.freecam;
        if (fc.isEnabled() && fc.cameraReady()) {
            cir.setReturnValue(new Vec3(fc.camX(), fc.camY(), fc.camZ()));
        }
    }
}
