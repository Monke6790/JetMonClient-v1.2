package com.example.clickgui.mixin;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.impl.Freecam;
import com.example.clickgui.module.impl.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Saat Freecam / Freelook aktif, gerakan mouse (atau sentuhan) tidak memutar pemain,
 * tetapi memutar kamera modul. Faktor 0.15 sama dengan yang dipakai Entity.turn bawaan.
 */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true, require = 0)
    private void jetmon$turn(double yRot, double xRot, CallbackInfo ci) {
        if ((Object) this != Minecraft.getInstance().player) return;
        MixinStatus.turnSeen = true;

        Freecam fc = ClickGuiMod.MODULES.freecam;
        if (fc.isEnabled() && fc.cameraReady()) {
            fc.updateRotation(yRot * 0.15, xRot * 0.15);
            ci.cancel();
            return;
        }
        Freelook fl = ClickGuiMod.MODULES.freelook;
        if (fl.isEnabled() && fl.cameraReady()) {
            fl.updateRotation(yRot * 0.15, xRot * 0.15);
            ci.cancel();
        }
    }
}
