package com.example.clickgui.module.impl;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.mixin.MixinStatus;
import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;
import com.example.clickgui.module.util.CameraMiner;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.CameraType;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWScrollCallback;

import java.lang.reflect.Method;

/**
 * Kamera bebas terbang. Pemain diam di tempat dan tetap digambar (pola Freecam Glazed).
 *
 * Modul menyimpan posisi + yaw/pitch kamera sendiri. EntityMixin mengalihkan gerakan mouse ke sini,
 * CameraMixin mengganti posisi & rotasi kamera dan menandainya "detached" agar badan pemain terlihat.
 * Gerak per frame (delta waktu), tombol dibaca langsung dari GLFW, sprint 2x, scroll mengubah kecepatan,
 * FOV effect & view bobbing dimatikan, Stay sneaking, paksa first person, mati otomatis saat
 * respawn / logout. Rotasi pemain tidak pernah berubah.
 */
public class Freecam extends Module {
    private final BoolSetting disableOnDamage = bool("Disable on damage", true);
    private final BoolSetting disableOnDeath = bool("Disable on death", true);
    private final BoolSetting disableOnLogout = bool("Disable on logout", true);
    /** Jika sedang sneak saat freecam dinyalakan, tetap sneak (tidak jatuh dari tepi, gali bawah air lebih cepat). */
    private final BoolSetting staySneaking = bool("Stay sneaking", true);
    /** Tampilkan tangan di layar saat freecam. */
    private final BoolSetting renderHands = bool("Render hands", true);
    /** Kecepatan dalam blok per detik (sprint = 2x). */
    public final NumberSetting speed = number("Speed", 1, 100, 1, 10);

    private boolean active;
    private double camX, camY, camZ;   // posisi kamera
    private float yaw, pitch;          // rotasi kamera

    private float lastHealth = -1f;
    private Player lastPlayer;
    private CameraType previousType;
    private double savedFovEffect;
    private boolean savedBob;
    private boolean optionsSaved;
    private boolean sneakOnEnable;
    private long lastFrameNanos;
    private int activeTicks;
    private boolean warned;
    private final CameraMiner miner = new CameraMiner();

    // Status tombol gerak yang dicatat di awal tick (cadangan bila polling GLFW tidak tersedia)
    private boolean tFwd, tBack, tRight, tLeft, tUp, tDown, tSprint;

    private static Method setRenderHand;

    public Freecam() { super("Freecam", Category.MISC); }

    @Override public boolean persistent() { return false; }

    // ---- dibaca oleh mixin ----
    public boolean cameraReady() { return active; }
    public double camX() { return camX; }
    public double camY() { return camY; }
    public double camZ() { return camZ; }
    public float yaw() { return yaw; }
    public float pitch() { return pitch; }

    /** Dipanggil EntityMixin dengan gerakan mouse yang sudah dikali 0.15. */
    public void updateRotation(double deltaYaw, double deltaPitch) {
        yaw = Mth.wrapDegrees(yaw + (float) deltaYaw);
        pitch = Mth.clamp(pitch + (float) deltaPitch, -90.0f, 90.0f);
    }

    @Override
    public void onWorldChanged() {
        active = false; // jangan menyentuh pemain di dunia baru
        if (disableOnLogout.get()) setEnabled(false);
        else { setEnabled(false); setEnabled(true); }
    }

    @Override
    protected void onEnable() {
        lastHealth = -1f;
        Player p = mc.player;
        if (p == null) return;
        ClickGuiMod.MODULES.freelook.setEnabled(false); // tidak boleh bersamaan

        lastPlayer = p;
        previousType = mc.options.getCameraType();

        Vec3 eye = p.getEyePosition();
        camX = eye.x;
        camY = eye.y;
        camZ = eye.z;
        yaw = p.getYRot();
        pitch = p.getXRot();

        // Dari third person depan: balik arah pandang supaya kamera tidak terbalik
        if (previousType == CameraType.THIRD_PERSON_FRONT) {
            yaw = Mth.wrapDegrees(yaw + 180f);
            pitch = -pitch;
        }
        mc.options.setCameraType(CameraType.FIRST_PERSON);

        savedFovEffect = mc.options.fovEffectScale().get();
        savedBob = mc.options.bobView().get();
        optionsSaved = true;
        mc.options.fovEffectScale().set(0.0);
        mc.options.bobView().set(false);

        sneakOnEnable = p.isShiftKeyDown();
        p.setDeltaMovement(Vec3.ZERO); // hentikan luncuran pemain
        lastFrameNanos = System.nanoTime();
        activeTicks = 0;
        warned = false;
        active = true;
        setHandVisible(renderHands.get());
    }

    @Override
    protected void onDisable() {
        miner.stop();
        active = false;
        setHandVisible(true);
        sneakOnEnable = false;
        lastPlayer = null;
        if (optionsSaved) {
            mc.options.fovEffectScale().set(savedFovEffect);
            mc.options.bobView().set(savedBob);
            optionsSaved = false;
        }
        if (previousType != null) mc.options.setCameraType(previousType);
        previousType = null;
    }

    @Override
    public void onPreTick() {
        if (!active || mc.player == null || mc.level == null) return;

        // Respawn / pemain baru: matikan (seperti Glazed)
        if (mc.player != lastPlayer) { setEnabled(false); return; }

        float hp = mc.player.getHealth();
        if (lastHealth < 0f) lastHealth = hp;
        if (disableOnDeath.get() && hp <= 0f) { setEnabled(false); return; }
        if (disableOnDamage.get() && hp < lastHealth - 0.01f) { setEnabled(false); return; }
        lastHealth = hp;

        // Diagnostik: beri tahu jika mixin kamera tidak terpasang
        if (!warned && ++activeTicks >= 40) {
            warned = true;
            if (!MixinStatus.cameraSetup || !MixinStatus.positionApplied || !MixinStatus.rotationApplied) {
                chat("[JetMonClient] Freecam: mixin kamera tidak terpasang (setup=" + MixinStatus.cameraSetup
                    + ", posisi=" + MixinStatus.positionApplied + ", rotasi=" + MixinStatus.rotationApplied
                    + "). Kirim latest.log ke pembuat mod.");
            }
        }

        setHandVisible(renderHands.get());

        Options o = mc.options;
        boolean keepSneak = staySneaking.get() && sneakOnEnable;

        // Catat tombol gerak sebelum dikosongkan (tombol sneak diabaikan jika kita yang menahannya)
        tFwd = o.keyUp.isDown();
        tBack = o.keyDown.isDown();
        tLeft = o.keyLeft.isDown();
        tRight = o.keyRight.isDown();
        tUp = o.keyJump.isDown();
        tDown = !keepSneak && o.keyShift.isDown();
        tSprint = o.keySprint.isDown();

        // Gali blok di tengah layar kamera (hanya yang masih dalam jangkauan tubuh pemain)
        miner.update(new Vec3(camX, camY, camZ), yaw, pitch, 8.0);

        // Pemain tidak ikut bergerak saat freecam
        o.keyUp.setDown(false);
        o.keyDown.setDown(false);
        o.keyLeft.setDown(false);
        o.keyRight.setDown(false);
        o.keyJump.setDown(false);
        o.keyShift.setDown(false);
        o.keySprint.setDown(false);
        if (keepSneak) o.keyShift.setDown(true);

        if (o.getCameraType() != CameraType.FIRST_PERSON) o.setCameraType(CameraType.FIRST_PERSON);
    }

    /** Dipanggil CameraMixin di awal setup kamera tiap frame: gerakkan kamera dengan delta waktu. */
    public void onCameraSetup() {
        if (!active || mc.player == null || mc.options == null) return;

        long now = System.nanoTime();
        float dt = Mth.clamp((now - lastFrameNanos) / 1.0e9f, 0.001f, 0.1f);
        lastFrameNanos = now;
        if (mc.screen != null) return;

        Options o = mc.options;
        boolean keepSneak = staySneaking.get() && sneakOnEnable;
        boolean fwd = polled(o.keyUp) || tFwd;
        boolean back = polled(o.keyDown) || tBack;
        boolean left = polled(o.keyLeft) || tLeft;
        boolean right = polled(o.keyRight) || tRight;
        boolean up = polled(o.keyJump) || tUp;
        boolean down = keepSneak ? polled(o.keyShift) : (polled(o.keyShift) || tDown);
        boolean sprint = polled(o.keySprint) || tSprint;

        double rad = Math.toRadians(yaw);
        double fx = -Math.sin(rad), fz = Math.cos(rad);   // maju (datar)
        double rx = -Math.cos(rad), rz = -Math.sin(rad);  // kanan

        double mx = 0, my = 0, mz = 0;
        if (fwd)   { mx += fx; mz += fz; }
        if (back)  { mx -= fx; mz -= fz; }
        if (right) { mx += rx; mz += rz; }
        if (left)  { mx -= rx; mz -= rz; }
        if (up)    my += 1;
        if (down)  my -= 1;

        double len = Math.sqrt(mx * mx + my * my + mz * mz);
        if (len > 1.0e-6) {
            double step = speed.get() * (sprint ? 2.0 : 1.0) * dt / len;
            camX += mx * step;
            camY += my * step;
            camZ += mz * step;
        }
    }

    /** Membaca status tombol langsung dari GLFW (tombol game dikosongkan tiap tick). */
    private boolean polled(KeyMapping bind) {
        if (bind == null || mc.getWindow() == null) return false;
        try {
            InputConstants.Key key = InputConstants.getKey(bind.saveString());
            if (key == null || key.equals(InputConstants.UNKNOWN)) return false;
            long window = mc.getWindow().handle();
            int state = key.getType() == InputConstants.Type.MOUSE
                ? GLFW.glfwGetMouseButton(window, key.getValue())
                : GLFW.glfwGetKey(window, key.getValue());
            return state == GLFW.GLFW_PRESS;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Tampilkan/sembunyikan tangan lewat reflection (nama method bisa berubah antar versi). */
    private void setHandVisible(boolean visible) {
        try {
            Object renderer = Minecraft.class.getField("gameRenderer").get(mc);
            if (setRenderHand == null) {
                setRenderHand = renderer.getClass().getMethod("setRenderHand", boolean.class);
            }
            setRenderHand.invoke(renderer, visible);
        } catch (Throwable ignored) {
            // tidak didukung di versi ini: opsi Render hands tidak berefek
        }
    }

    /**
     * Scroll mouse mengubah Speed saat Freecam aktif. Langkahnya 15% dari kecepatan (minimal 1).
     * Hanya terpasang jika GLFW mendukung; di layar sentuh biasanya tidak ada scroll.
     */
    public void installScrollHook() {
        try {
            long window = GLFW.glfwGetCurrentContext();
            if (window == 0L) return;
            GLFWScrollCallback[] previous = new GLFWScrollCallback[1];
            previous[0] = GLFW.glfwSetScrollCallback(window, (w, dx, dy) -> {
                if (isEnabled() && active && mc.screen == null && dy != 0) {
                    double step = Math.max(1.0, speed.get() * 0.15);
                    speed.set(speed.get() + (dy > 0 ? step : -step));
                } else if (previous[0] != null) {
                    previous[0].invoke(w, dx, dy);
                }
            });
        } catch (Throwable ignored) {
            // GLFW tidak mendukung callback ini: kecepatan tetap diatur lewat slider
        }
    }
}
