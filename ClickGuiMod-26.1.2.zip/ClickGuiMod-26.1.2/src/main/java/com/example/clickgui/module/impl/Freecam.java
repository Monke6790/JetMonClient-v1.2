package com.example.clickgui.module.impl;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.CameraType;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWScrollCallback;

import java.lang.reflect.Method;

/**
 * Kamera bebas terbang. Pemain diam di tempat dan tetap digambar.
 *
 * Pola seperti Freecam Glazed: kamera tetap memakai pemain, CameraMixin mengganti posisi kamera
 * dengan posisi freecam dan menandai kamera "detached" supaya badan pemain terlihat. Gerak per frame
 * (delta waktu), tombol dibaca langsung dari GLFW, sprint 2x, scroll mengubah kecepatan, FOV effect &
 * view bobbing dimatikan, Stay sneaking, paksa first person, mati otomatis saat respawn/logout.
 *
 * Arah pandang: di luar tick rotasi pemain diisi rotasi kamera (hasil mouse); saat tick berjalan
 * dikembalikan ke arah asli, jadi pemain tidak ikut berputar atau berjalan.
 */
public class Freecam extends Module {
    private final BoolSetting disableOnDamage = bool("Disable on damage", true);
    private final BoolSetting disableOnDeath = bool("Disable on death", true);
    private final BoolSetting disableOnLogout = bool("Disable on logout", true);
    /** Jika sedang sneak saat freecam dinyalakan, tetap sneak (tidak jatuh dari tepi, gali bawah air lebih cepat). */
    private final BoolSetting staySneaking = bool("Stay sneaking", true);
    /** Tampilkan tangan di layar saat freecam. */
    private final BoolSetting renderHands = bool("Render hands", true);
    /** Kecepatan dalam blok per detik (sprint = 2x). */
    public final NumberSetting speed = number("Speed", 1, 100, 1, 10);

    private boolean active;
    private double camX, camY, camZ;          // posisi kamera
    private float camYaw, camPitch;           // rotasi kamera (hasil mouse)
    private float bodyYaw, bodyPitch;         // arah hadap asli pemain

    private float lastHealth = -1f;
    private Player lastPlayer;
    private CameraType previousType;
    private double savedFovEffect;
    private boolean savedBob;
    private boolean optionsSaved;
    private boolean sneakOnEnable;
    private boolean mining;
    private long lastFrameNanos;

    // Status tombol gerak yang dicatat di awal tick (cadangan bila polling GLFW tidak tersedia)
    private boolean tFwd, tBack, tRight, tLeft, tUp, tDown, tSprint;

    private static Method setRenderHand;

    public Freecam() { super("Freecam", Category.MISC); }

    @Override public boolean persistent() { return false; }

    // ---- dibaca oleh CameraMixin ----
    public boolean cameraReady() { return active; }
    public double camX() { return camX; }
    public double camY() { return camY; }
    public double camZ() { return camZ; }

    @Override
    public void onWorldChanged() {
        active = false; // jangan menyentuh pemain di dunia baru
        mining = false;
        if (disableOnLogout.get()) setEnabled(false);
        else { setEnabled(false); setEnabled(true); }
    }

    @Override
    protected void onEnable() {
        lastHealth = -1f;
        Player p = mc.player;
        if (p == null) return;
        ClickGuiMod.MODULES.freelook.setEnabled(false); // tidak boleh bersamaan

        lastPlayer = p;
        previousType = mc.options.getCameraType();

        Vec3 eye = p.getEyePosition();
        camX = eye.x;
        camY = eye.y;
        camZ = eye.z;
        bodyYaw = camYaw = p.getYRot();
        bodyPitch = camPitch = p.getXRot();

        // Dari third person depan: balik arah pandang supaya kamera tidak terbalik
        if (previousType == CameraType.THIRD_PERSON_FRONT) {
            camYaw += 180f;
            camPitch = -camPitch;
            setRot(camYaw, camPitch);
        }
        mc.options.setCameraType(CameraType.FIRST_PERSON);

        savedFovEffect = mc.options.fovEffectScale().get();
        savedBob = mc.options.bobView().get();
        optionsSaved = true;
        mc.options.fovEffectScale().set(0.0);
        mc.options.bobView().set(false);

        sneakOnEnable = p.isShiftKeyDown();
        p.setDeltaMovement(Vec3.ZERO); // hentikan luncuran pemain
        lastFrameNanos = System.nanoTime();
        mining = false;
        active = true;
        setHandVisible(renderHands.get());
    }

    @Override
    protected void onDisable() {
        if (mining && mc.gameMode != null) mc.gameMode.stopDestroyBlock();
        mining = false;
        if (active) setRot(bodyYaw, bodyPitch); // kembalikan arah hadap asli
        active = false;
        setHandVisible(true);
        sneakOnEnable = false;
        lastPlayer = null;
        if (optionsSaved) {
            mc.options.fovEffectScale().set(savedFovEffect);
            mc.options.bobView().set(savedBob);
            optionsSaved = false;
        }
        if (previousType != null) mc.options.setCameraType(previousType);
        previousType = null;
    }

    private void setRot(float yaw, float pitch) {
        Player p = mc.player;
        if (p == null) return;
        p.setYRot(yaw);
        p.yRotO = yaw;
        p.setXRot(pitch);
        p.xRotO = pitch;
    }

    /** Awal tick: ambil rotasi kamera dari mouse, gali sesuai kamera, lalu kembalikan pemain ke arah asli. */
    @Override
    public void onPreTick() {
        if (!active || mc.player == null || mc.level == null) return;

        // Respawn / pemain baru: matikan (seperti Glazed)
        if (mc.player != lastPlayer) { setEnabled(false); return; }

        float hp = mc.player.getHealth();
        if (lastHealth < 0f) lastHealth = hp;
        if (disableOnDeath.get() && hp <= 0f) { setEnabled(false); return; }
        if (disableOnDamage.get() && hp < lastHealth - 0.01f) { setEnabled(false); return; }
        lastHealth = hp;

        setHandVisible(renderHands.get());

        camYaw = mc.player.getYRot();   // saat ini pemain masih berisi rotasi kamera
        camPitch = mc.player.getXRot();

        Options o = mc.options;
        boolean keepSneak = staySneaking.get() && sneakOnEnable;

        // Catat tombol gerak sebelum dikosongkan (tombol sneak diabaikan jika kita yang menahannya)
        tFwd = o.keyUp.isDown();
        tBack = o.keyDown.isDown();
        tLeft = o.keyLeft.isDown();
        tRight = o.keyRight.isDown();
        tUp = o.keyJump.isDown();
        tDown = !keepSneak && o.keyShift.isDown();
        tSprint = o.keySprint.isDown();

        mineFromCamera();

        setRot(bodyYaw, bodyPitch); // logika tick memakai arah asli

        // Pemain tidak ikut bergerak saat freecam
        o.keyUp.setDown(false);
        o.keyDown.setDown(false);
        o.keyLeft.setDown(false);
        o.keyRight.setDown(false);
        o.keyJump.setDown(false);
        o.keyShift.setDown(false);
        o.keySprint.setDown(false);
        if (keepSneak) o.keyShift.setDown(true);

        if (o.getCameraType() != CameraType.FIRST_PERSON) o.setCameraType(CameraType.FIRST_PERSON);
    }

    /** Akhir tick: isi rotasi pemain dengan rotasi kamera agar frame berikutnya memakainya. */
    @Override
    public void onTick() {
        if (!active || mc.player == null) return;
        setRot(camYaw, camPitch);
    }

    /** Dipanggil CameraMixin di awal setup kamera tiap frame: gerakkan kamera dengan delta waktu. */
    public void onCameraSetup() {
        if (!active || mc.player == null || mc.options == null) return;

        long now = System.nanoTime();
        float dt = Mth.clamp((now - lastFrameNanos) / 1.0e9f, 0.001f, 0.1f);
        lastFrameNanos = now;
        if (mc.screen != null) return;

        Options o = mc.options;
        boolean keepSneak = staySneaking.get() && sneakOnEnable;
        boolean fwd = polled(o.keyUp) || tFwd;
        boolean back = polled(o.keyDown) || tBack;
        boolean left = polled(o.keyLeft) || tLeft;
        boolean right = polled(o.keyRight) || tRight;
        boolean up = polled(o.keyJump) || tUp;
        boolean down = keepSneak ? polled(o.keyShift) : (polled(o.keyShift) || tDown);
        boolean sprint = polled(o.keySprint) || tSprint;

        double yaw = Math.toRadians(mc.player.getYRot()); // rotasi kamera saat ini
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // maju (datar)
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);  // kanan

        double mx = 0, my = 0, mz = 0;
        if (fwd)   { mx += fx; mz += fz; }
        if (back)  { mx -= fx; mz -= fz; }
        if (right) { mx += rx; mz += rz; }
        if (left)  { mx -= rx; mz -= rz; }
        if (up)    my += 1;
        if (down)  my -= 1;

        double len = Math.sqrt(mx * mx + my * my + mz * mz);
        if (len > 1.0e-6) {
            double step = speed.get() * (sprint ? 2.0 : 1.0) * dt / len;
            camX += mx * step;
            camY += my * step;
            camZ += mz * step;
        }
    }

    /**
     * Menggali blok di tengah layar kamera. Hanya blok yang masih dalam jangkauan tubuh pemain yang
     * digali (server menolak yang lebih jauh). Serangan bawaan dimatikan di tick ini karena bawaannya
     * mengarah ke depan badan, bukan ke kamera.
     */
    private void mineFromCamera() {
        if (mc.gameMode == null || mc.level == null) return;
        Options o = mc.options;

        boolean clicked = false;
        while (o.keyAttack.consumeClick()) clicked = true;
        boolean held = mc.screen == null && (clicked || o.keyAttack.isDown() || mc.mouseHandler.isLeftPressed());
        o.keyAttack.setDown(false);

        if (held) {
            double yaw = Math.toRadians(camYaw), pitch = Math.toRadians(camPitch);
            Vec3 dir = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
            Vec3 from = new Vec3(camX, camY, camZ);
            BlockHitResult hit = mc.level.clip(new ClipContext(from, from.add(dir.scale(8.0)),
                ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, mc.player));
            if (hit.getType() == HitResult.Type.BLOCK) {
                double reach = mc.player.isCreative() ? 5.0 : 4.5;
                double dist = mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(hit.getBlockPos()));
                if (dist <= reach + 0.8) {
                    if (mc.gameMode.continueDestroyBlock(hit.getBlockPos(), hit.getDirection())) {
                        mc.player.swing(InteractionHand.MAIN_HAND);
                    }
                    mining = true;
                    return;
                }
            }
        }
        if (mining) {
            mc.gameMode.stopDestroyBlock();
            mining = false;
        }
    }

    /** Membaca status tombol langsung dari GLFW (tombol game dikosongkan tiap tick). */
    private boolean polled(KeyMapping bind) {
        if (bind == null || mc.getWindow() == null) return false;
        try {
            InputConstants.Key key = InputConstants.getKey(bind.saveString());
            if (key == null || key.equals(InputConstants.UNKNOWN)) return false;
            long window = mc.getWindow().handle();
            int state = key.getType() == InputConstants.Type.MOUSE
                ? GLFW.glfwGetMouseButton(window, key.getValue())
                : GLFW.glfwGetKey(window, key.getValue());
            return state == GLFW.GLFW_PRESS;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Tampilkan/sembunyikan tangan lewat reflection (nama method bisa berubah antar versi). */
    private void setHandVisible(boolean visible) {
        try {
            Object renderer = Minecraft.class.getField("gameRenderer").get(mc);
            if (setRenderHand == null) {
                setRenderHand = renderer.getClass().getMethod("setRenderHand", boolean.class);
            }
            setRenderHand.invoke(renderer, visible);
        } catch (Throwable ignored) {
            // tidak didukung di versi ini: opsi Render hands tidak berefek
        }
    }

    /**
     * Scroll mouse mengubah Speed saat Freecam aktif. Langkahnya 15% dari kecepatan (minimal 1).
     * Hanya terpasang jika GLFW mendukung; di layar sentuh biasanya tidak ada scroll.
     */
    public void installScrollHook() {
        try {
            long window = GLFW.glfwGetCurrentContext();
            if (window == 0L) return;
            GLFWScrollCallback[] previous = new GLFWScrollCallback[1];
            previous[0] = GLFW.glfwSetScrollCallback(window, (w, dx, dy) -> {
                if (isEnabled() && active && mc.screen == null && dy != 0) {
                    double step = Math.max(1.0, speed.get() * 0.15);
                    speed.set(speed.get() + (dy > 0 ? step : -step));
                } else if (previous[0] != null) {
                    previous[0].invoke(w, dx, dy);
                }
            });
        } catch (Throwable ignored) {
            // GLFW tidak mendukung callback ini: kecepatan tetap diatur lewat slider
        }
    }
}
