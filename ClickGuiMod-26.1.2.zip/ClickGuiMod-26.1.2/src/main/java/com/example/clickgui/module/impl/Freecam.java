package com.example.clickgui.module.impl;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;
import com.example.clickgui.module.util.CameraRig;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.client.Options;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.phys.Vec3;

/** Kamera bebas terbang. Pemain diam di tempat selama modul aktif. */
public class Freecam extends Module {
    /** Kecepatan dalam blok per detik (bisa diatur di ClickGUI). */
    public final NumberSetting speed = number("Speed", 1, 100, 1, 10);

    public Freecam() { super("Freecam", Category.MISC); }

    @Override
    protected void onEnable() {
        if (mc.player != null) CameraRig.start(this, mc.player.getEyePosition());
    }

    @Override
    protected void onDisable() { CameraRig.stop(this); }

    @Override
    public void onPreTick() {
        if (mc.player == null || mc.level == null) return;
        if (!CameraRig.valid(this)) {
            CameraRig.start(this, mc.player.getEyePosition());
            if (!CameraRig.valid(this)) return;
        }
        Marker c = CameraRig.camera();
        Options o = mc.options;

        if (mc.screen == null) {
            double f = (o.keyUp.isDown() ? 1 : 0) - (o.keyDown.isDown() ? 1 : 0);
            double s = (o.keyRight.isDown() ? 1 : 0) - (o.keyLeft.isDown() ? 1 : 0);
            double v = (o.keyJump.isDown() ? 1 : 0) - (o.keyShift.isDown() ? 1 : 0);

            double yaw = Math.toRadians(c.getYRot());
            Vec3 look = c.getViewVector(1.0f);
            Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
            Vec3 move = look.scale(f).add(right.scale(s)).add(0, v, 0);

            CameraRig.syncOld();
            if (move.lengthSqr() > 1.0e-6) {
                move = move.normalize().scale(speed.get() / 20.0);
                c.setPos(c.getX() + move.x, c.getY() + move.y, c.getZ() + move.z);
            }
        }

        // Pemain tidak ikut bergerak/menyerang saat freecam
        o.keyUp.setDown(false);
        o.keyDown.setDown(false);
        o.keyLeft.setDown(false);
        o.keyRight.setDown(false);
        o.keyJump.setDown(false);
        o.keyShift.setDown(false);
        o.keySprint.setDown(false);
        o.keyAttack.setDown(false);
        o.keyUse.setDown(false);
    }

    /** Hook per-frame: putar kamera mengikuti mouse. */
    @Override
    public void extract(WorldShapes shapes, float pt) {
        if (CameraRig.valid(this)) CameraRig.pumpRotation();
    }
}
