package com.example.clickgui.module.impl;

import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.NumberSetting;
import com.example.clickgui.module.util.CameraRig;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWScrollCallback;

import java.lang.reflect.Method;

/**
 * Kamera bebas terbang, pemain diam. Opsi mirip Freecam Meteor:
 * auto-off saat damage/mati/logout, Render hands, Rotate, dan scroll untuk kecepatan.
 */
public class Freecam extends Module {
    private final BoolSetting disableOnDamage = bool("Disable on damage", true);
    private final BoolSetting disableOnDeath = bool("Disable on death", true);
    private final BoolSetting disableOnLogout = bool("Disable on logout", true);
    /** Tampilkan tangan di layar saat freecam. */
    private final BoolSetting renderHands = bool("Render hands", false);
    /** Putar tubuh pemain ke blok/entity yang diklik dari kamera. */
    private final BoolSetting rotate = bool("Rotate", false);
    /** Boleh menggali blok yang diarahkan kamera (server tetap membatasi jarak dari tubuh pemain). */
    private final BoolSetting mining = bool("Mining", true);
    /** Boleh klik kanan (pasang blok / pakai item) dari sudut pandang kamera. */
    private final BoolSetting interact = bool("Interact", false);
    /** Kecepatan dalam blok per detik. */
    public final NumberSetting speed = number("Speed", 1, 100, 1, 10);

    private float lastHealth = -1f;
    private static Method setRenderHand;

    public Freecam() { super("Freecam", Category.MISC); }

    @Override public boolean persistent() { return false; }

    @Override
    public void onWorldChanged() {
        if (disableOnLogout.get()) setEnabled(false);
        else { onDisable(); onEnable(); }
    }

    @Override
    protected void onEnable() {
        lastHealth = -1f;
        if (mc.player != null) CameraRig.start(this, mc.player.getEyePosition());
        setHandVisible(renderHands.get());
    }

    @Override
    protected void onDisable() {
        CameraRig.stop(this);
        setHandVisible(true);
    }

    @Override
    public void onPreTick() {
        if (mc.player == null || mc.level == null) return;

        if (!CameraRig.valid(this)) {
            // Rig lama dari dunia sebelumnya = pemain logout lalu masuk lagi
            if (disableOnLogout.get() && CameraRig.ownedBy(this)) { setEnabled(false); return; }
            CameraRig.start(this, mc.player.getEyePosition());
            if (!CameraRig.valid(this)) return;
        }

        float hp = mc.player.getHealth();
        if (lastHealth < 0f) lastHealth = hp;
        if (disableOnDeath.get() && hp <= 0f) { setEnabled(false); return; }
        if (disableOnDamage.get() && hp < lastHealth - 0.01f) { setEnabled(false); return; }
        lastHealth = hp;

        setHandVisible(renderHands.get());

        Marker c = CameraRig.camera();
        Options o = mc.options;

        if (mc.screen == null) {
            double f = (o.keyUp.isDown() ? 1 : 0) - (o.keyDown.isDown() ? 1 : 0);
            double s = (o.keyRight.isDown() ? 1 : 0) - (o.keyLeft.isDown() ? 1 : 0);
            double v = (o.keyJump.isDown() ? 1 : 0) - (o.keyShift.isDown() ? 1 : 0);

            double yaw = Math.toRadians(c.getYRot());
            Vec3 look = c.getViewVector(1.0f);
            Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
            Vec3 move = look.scale(f).add(right.scale(s)).add(0, v, 0);

            CameraRig.syncOld();
            if (move.lengthSqr() > 1.0e-6) {
                move = move.normalize().scale(speed.get() / 20.0);
                c.setPos(c.getX() + move.x, c.getY() + move.y, c.getZ() + move.z);
            }

            // Rotate: hadapkan tubuh pemain ke titik yang diklik dari kamera
            boolean acting = (mining.get() && o.keyAttack.isDown()) || (interact.get() && o.keyUse.isDown());
            HitResult hit = mc.hitResult;
            if (rotate.get() && acting && hit != null && hit.getType() != HitResult.Type.MISS) {
                Vec3 eye = mc.player.getEyePosition();
                Vec3 t = hit.getLocation();
                double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z;
                double horizontal = Math.sqrt(dx * dx + dz * dz);
                float yawDeg = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
                float pitchDeg = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
                CameraRig.aimPlayer(yawDeg, Mth.clamp(pitchDeg, -90f, 90f));
            }
        }

        // Pemain tidak ikut bergerak saat freecam
        o.keyUp.setDown(false);
        o.keyDown.setDown(false);
        o.keyLeft.setDown(false);
        o.keyRight.setDown(false);
        o.keyJump.setDown(false);
        o.keyShift.setDown(false);
        o.keySprint.setDown(false);
        if (!mining.get()) o.keyAttack.setDown(false);
        if (!interact.get()) o.keyUse.setDown(false);
    }

    /** Hook per-frame: putar kamera mengikuti mouse. */
    @Override
    public void extract(WorldShapes shapes, float pt) {
        if (CameraRig.valid(this)) CameraRig.pumpRotation();
    }

    /** Tampilkan/sembunyikan tangan lewat reflection (nama method bisa berubah antar versi). */
    private void setHandVisible(boolean visible) {
        try {
            Object renderer = Minecraft.class.getField("gameRenderer").get(mc);
            if (setRenderHand == null) {
                setRenderHand = renderer.getClass().getMethod("setRenderHand", boolean.class);
            }
            setRenderHand.invoke(renderer, visible);
        } catch (Throwable ignored) {
            // tidak didukung di versi ini: opsi Render hands tidak berefek
        }
    }

    /**
     * Scroll mouse mengubah Speed saat Freecam aktif (seperti Meteor).
     * Hanya terpasang jika GLFW mendukung; di layar sentuh biasanya tidak ada scroll.
     */
    public void installScrollHook() {
        try {
            long window = GLFW.glfwGetCurrentContext();
            if (window == 0L) return;
            GLFWScrollCallback[] previous = new GLFWScrollCallback[1];
            previous[0] = GLFW.glfwSetScrollCallback(window, (w, dx, dy) -> {
                if (isEnabled() && mc.screen == null && CameraRig.ownedBy(this)) {
                    speed.set(speed.get() + dy * 5);
                } else if (previous[0] != null) {
                    previous[0].invoke(w, dx, dy);
                }
            });
        } catch (Throwable ignored) {
            // GLFW tidak mendukung callback ini: kecepatan tetap diatur lewat slider
        }
    }
}
