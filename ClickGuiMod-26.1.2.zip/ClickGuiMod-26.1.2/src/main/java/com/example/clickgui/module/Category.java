package com.example.clickgui.module;

public enum Category {
    RENDER("RENDER"), COMBAT("COMBAT"), MOVEMENT("MOVEMENT"), MISC("MISC");

    public final String label;
    Category(String label) { this.label = label; }
}
