package com.example.clickgui.module.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Menggali blok di arah kamera (bukan arah badan). Serangan bawaan Minecraft dimatikan di tick ini
 * karena bawaannya mengarah ke depan badan. Server tetap menolak blok yang jauh dari tubuh pemain.
 */
public final class CameraMiner {
    private boolean mining;

    /** Panggil di awal tick. */
    public void update(Vec3 from, float yawDeg, float pitchDeg, double rayLength) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.gameMode == null || mc.level == null || mc.player == null) return;
        Options o = mc.options;

        boolean clicked = false;
        while (o.keyAttack.consumeClick()) clicked = true;
        boolean held = mc.screen == null && (clicked || o.keyAttack.isDown() || mc.mouseHandler.isLeftPressed());
        o.keyAttack.setDown(false);

        if (held) {
            double yaw = Math.toRadians(yawDeg), pitch = Math.toRadians(pitchDeg);
            Vec3 dir = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
            BlockHitResult hit = mc.level.clip(new ClipContext(from, from.add(dir.scale(rayLength)),
                ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, mc.player));
            if (hit.getType() == HitResult.Type.BLOCK) {
                double reach = (mc.player.isCreative() ? 5.0 : 4.5) + 0.8;
                double dist = mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(hit.getBlockPos()));
                if (dist <= reach) {
                    if (mc.gameMode.continueDestroyBlock(hit.getBlockPos(), hit.getDirection())) {
                        mc.player.swing(InteractionHand.MAIN_HAND);
                    }
                    mining = true;
                    return;
                }
            }
        }
        stop();
    }

    public void stop() {
        Minecraft mc = Minecraft.getInstance();
        if (mining && mc.gameMode != null) mc.gameMode.stopDestroyBlock();
        mining = false;
    }
}
