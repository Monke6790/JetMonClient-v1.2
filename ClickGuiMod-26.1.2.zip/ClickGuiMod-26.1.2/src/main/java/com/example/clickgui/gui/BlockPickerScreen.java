package com.example.clickgui.gui;

import com.example.clickgui.module.impl.BlockEsp;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Layar pencarian blok untuk BlockESP. Tap blok untuk memilih / membatalkan. */
public class BlockPickerScreen extends Screen {
    private static final int X = 20, W = 260, ROW_H = 22, LIST_TOP = 48, BOTTOM = 34;
    private static List<Block> allBlocks;

    private final Screen parent;
    private final BlockEsp module;
    private EditBox search;
    private final List<Block> filtered = new ArrayList<>();
    private int page;

    public BlockPickerScreen(Screen parent, BlockEsp module) {
        super(Component.literal("Select blocks"));
        this.parent = parent;
        this.module = module;
    }

    private static List<Block> allBlocks() {
        if (allBlocks == null) {
            List<Block> l = new ArrayList<>();
            for (Block b : BuiltInRegistries.BLOCK) {
                if (b.defaultBlockState().isAir()) continue;
                l.add(b);
            }
            l.sort(Comparator.comparing(BlockEsp::idOf));
            allBlocks = l;
        }
        return allBlocks;
    }

    @Override
    protected void init() {
        String old = search != null ? search.getValue() : "";
        search = new EditBox(font, X, 20, W, 20, Component.literal("Search"));
        search.setResponder(t -> { page = 0; refilter(); });
        search.setValue(old);
        addRenderableWidget(search);

        int y = height - 28;
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose())
            .bounds(X, y, 46, 20).build());
        addRenderableWidget(Button.builder(Component.literal("<"), b -> { if (page > 0) page--; })
            .bounds(X + 52, y, 28, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> { if (page < pages() - 1) page++; })
            .bounds(X + 84, y, 28, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+Shown"), b -> module.selected().addAll(filtered))
            .bounds(X + 118, y, 60, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Clear"), b -> module.selected().clear())
            .bounds(X + 184, y, 50, 20).build());
        refilter();
    }

    private void refilter() {
        String q = search.getValue().toLowerCase().trim().replace(' ', '_');
        filtered.clear();
        for (Block b : allBlocks()) {
            if (q.isEmpty() || BlockEsp.idOf(b).contains(q)) filtered.add(b);
        }
    }

    private int perPage() { return Math.max(1, (height - LIST_TOP - BOTTOM) / ROW_H); }
    private int pages() { return Math.max(1, (filtered.size() + perPage() - 1) / perPage()); }

    private static int argb(float[] c) {
        return 0xFF000000 | ((int) (c[0] * 255) << 16) | ((int) (c[1] * 255) << 8) | (int) (c[2] * 255);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);
        if (page >= pages()) page = pages() - 1;

        g.text(font, "Selected: " + module.selected().size() + "   Page " + (page + 1) + "/" + pages()
            + "   (" + filtered.size() + " blocks)", X, 8, 0xFFFFD84D, true);

        int per = perPage();
        int start = page * per;
        int end = Math.min(filtered.size(), start + per);
        for (int i = start; i < end; i++) {
            Block b = filtered.get(i);
            int ry = LIST_TOP + (i - start) * ROW_H;
            boolean on = module.selected().contains(b);
            g.fill(X, ry, X + W, ry + ROW_H - 2, on ? 0xFF2F4A2F : 0xFF2A2A2A);
            g.fill(X + 4, ry + 4, X + 14, ry + ROW_H - 6, argb(module.colorOf(b)));
            g.text(font, BlockEsp.idOf(b), X + 20, ry + 7, 0xFFFFFFFF, true);
            String mark = on ? "[x]" : "[ ]";
            g.text(font, mark, X + W - 6 - font.width(mark), ry + 7, on ? 0xFF55FF55 : 0xFFAAAAAA, true);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true; // search box & tombol

        double mx = event.x(), my = event.y();
        int per = perPage();
        int start = page * per;
        int end = Math.min(filtered.size(), start + per);
        for (int i = start; i < end; i++) {
            int ry = LIST_TOP + (i - start) * ROW_H;
            if (mx >= X && mx <= X + W && my >= ry && my <= ry + ROW_H - 2) {
                Block b = filtered.get(i);
                if (!module.selected().remove(b)) module.selected().add(b);
                return true;
            }
        }
        return false;
    }

    @Override
    public void onClose() { Minecraft.getInstance().setScreen(parent); }
}
