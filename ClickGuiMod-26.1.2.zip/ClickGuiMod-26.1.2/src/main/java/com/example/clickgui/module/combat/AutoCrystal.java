package com.example.clickgui.module.combat;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Memasang end crystal di obsidian/bedrock dekat target dan meledakkannya.
 * Crystal terlalu dekat dengan pemain diabaikan supaya tidak kena ledakan sendiri.
 */
public class AutoCrystal extends CombatModule {
    private static final double REACH = 4.4;
    private static final double SAFE_DISTANCE = 3.5;
    private int cooldown;

    public AutoCrystal() { super("AutoCrystal"); }

    @Override
    protected void combatTick() {
        if (cooldown > 0) { cooldown--; return; }

        // 1) Ledakkan crystal yang aman dan terjangkau
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof EndCrystal)) continue;
            float d = mc.player.distanceTo(e);
            if (d >= SAFE_DISTANCE && d <= REACH) {
                mc.gameMode.attack(mc.player, e);
                mc.player.swing(InteractionHand.MAIN_HAND);
                cooldown = 2;
                return;
            }
        }

        // 2) Cari target terdekat
        Entity target = null;
        double best = 64.0;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || !(e instanceof Enemy || e instanceof Player)) continue;
            double d = mc.player.distanceToSqr(e);
            if (d < best) { best = d; target = e; }
        }
        if (target == null) return;

        // 3) Pegang crystal
        InteractionHand hand;
        if (mc.player.getOffhandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.OFF_HAND;
        else if (holding(s -> s.is(Items.END_CRYSTAL))) hand = InteractionHand.MAIN_HAND;
        else return;

        // 4) Cari dasar obsidian/bedrock terbaik di sekitar target
        BlockPos tp = target.blockPosition();
        Vec3 eye = mc.player.getEyePosition();
        BlockPos bestPos = null;
        double bestDist = Double.MAX_VALUE;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = -2; dy <= 0; dy++) {
                    BlockPos base = tp.offset(dx, dy, dz);
                    BlockState st = mc.level.getBlockState(base);
                    if (!(st.is(Blocks.OBSIDIAN) || st.is(Blocks.BEDROCK))) continue;
                    if (!mc.level.getBlockState(base.above()).isAir()
                        || !mc.level.getBlockState(base.above(2)).isAir()) continue;

                    Vec3 hit = Vec3.atCenterOf(base).add(0, 0.5, 0);
                    double dEye = eye.distanceTo(hit);
                    if (dEye > REACH) continue;
                    if (mc.player.position().distanceTo(Vec3.atBottomCenterOf(base.above())) < SAFE_DISTANCE) continue;
                    if (!mc.level.getEntities((Entity) null, new AABB(base.above()), x -> true).isEmpty()) continue;

                    double dTarget = target.position().distanceToSqr(Vec3.atBottomCenterOf(base.above()));
                    if (dTarget < bestDist) { bestDist = dTarget; bestPos = base; }
                }
            }
        }
        if (bestPos == null) return;

        Vec3 hitVec = Vec3.atCenterOf(bestPos).add(0, 0.5, 0);
        mc.gameMode.useItemOn(mc.player, hand, new BlockHitResult(hitVec, Direction.UP, bestPos, false));
        mc.player.swing(hand);
        cooldown = 2;
    }
}
