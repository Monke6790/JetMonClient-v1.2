package com.example.clickgui.module.impl;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.ModeSetting;
import com.example.clickgui.module.Module;
import net.minecraft.client.CameraType;
import net.minecraft.client.Options;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Melihat sekeliling tanpa memutar arah hadap pemain.
 *
 * Kamera tetap memakai pemain itu sendiri (jadi badan pemain tetap digambar di third person).
 * Di luar tick, rotasi pemain diisi rotasi kamera (hasil gerakan mouse); saat tick berjalan,
 * rotasi pemain dikembalikan ke arah asli sehingga gerak dan paket ke server memakai arah semula.
 *
 * Mining mengikuti arah kamera: apa yang kamu lihat (termasuk ke bawah) adalah yang digali.
 */
public class Freelook extends Module {
    /** OFF (bawaan): tekan sekali = ON, sekali lagi = OFF. ON: tahan tombol untuk melihat sekeliling. */
    private final BoolSetting hold = bool("Hold key", false);
    /** Kamera boleh menembus blok, tidak "mundur" saat menabrak dinding. */
    private final BoolSetting seeThroughWalls = bool("See through walls", false);
    private final ModeSetting view = mode("View", "Back", "Back", "Front", "First person");

    private float camYaw, camPitch;     // rotasi kamera (hasil mouse)
    private float bodyYaw, bodyPitch;   // arah hadap asli pemain
    private boolean active;
    private boolean mining;
    private CameraType previousType;
    private String appliedView = "";

    public Freelook() { super("Freelook", Category.MISC); }

    @Override public boolean persistent() { return false; }
    @Override public boolean holdKey() { return hold.get(); }

    public boolean seeThroughWalls() { return seeThroughWalls.get(); }

    @Override
    public void onWorldChanged() {
        active = false; // jangan menyentuh pemain di dunia baru
        mining = false;
        setEnabled(false);
    }

    @Override
    protected void onEnable() {
        Player p = mc.player;
        if (p == null) return;
        // Freecam dan Freelook tidak boleh aktif bersamaan
        ClickGuiMod.MODULES.freecam.setEnabled(false);

        bodyYaw = camYaw = p.getYRot();
        bodyPitch = camPitch = p.getXRot();
        active = true;
        mining = false;
        previousType = mc.options.getCameraType();
        applyView();
    }

    @Override
    protected void onDisable() {
        if (mining && mc.gameMode != null) mc.gameMode.stopDestroyBlock();
        mining = false;
        if (active) setRot(bodyYaw, bodyPitch); // kembalikan arah hadap asli
        active = false;
        if (previousType != null) mc.options.setCameraType(previousType);
        previousType = null;
        appliedView = "";
    }

    private void applyView() {
        String v = view.get();
        mc.options.setCameraType(switch (v) {
            case "Front" -> CameraType.THIRD_PERSON_FRONT;
            case "First person" -> CameraType.FIRST_PERSON;
            default -> CameraType.THIRD_PERSON_BACK;
        });
        appliedView = v;
    }

    private void setRot(float yaw, float pitch) {
        Player p = mc.player;
        if (p == null) return;
        p.setYRot(yaw);
        p.yRotO = yaw;
        p.setXRot(pitch);
        p.xRotO = pitch;
    }

    /** Awal tick: ambil rotasi kamera dari mouse, gali sesuai arah kamera, lalu kembalikan pemain ke arah asli. */
    @Override
    public void onPreTick() {
        if (!active || mc.player == null) return;
        camYaw = mc.player.getYRot();
        camPitch = mc.player.getXRot();

        mineAlongCamera(); // pemain masih berada di rotasi kamera di titik ini

        setRot(bodyYaw, bodyPitch);
        if (!view.get().equals(appliedView)) applyView();
    }

    /** Akhir tick: isi rotasi pemain dengan rotasi kamera agar frame berikutnya memakainya. */
    @Override
    public void onTick() {
        if (!active || mc.player == null) return;
        setRot(camYaw, camPitch);
    }

    /**
     * Menggali blok yang ada di arah kamera. Serangan bawaan Minecraft dimatikan di tick ini
     * karena bawaannya mengarah ke depan badan, bukan ke arah kamera.
     */
    private void mineAlongCamera() {
        if (mc.gameMode == null || mc.level == null) return;
        Options o = mc.options;

        boolean clicked = false;
        while (o.keyAttack.consumeClick()) clicked = true;
        boolean held = mc.screen == null && (clicked || o.keyAttack.isDown() || mc.mouseHandler.isLeftPressed());
        o.keyAttack.setDown(false);

        if (held) {
            HitResult hit = mc.player.pick(mc.player.isCreative() ? 5.0 : 4.5, 1.0f, false);
            if (hit instanceof BlockHitResult block && hit.getType() == HitResult.Type.BLOCK) {
                if (mc.gameMode.continueDestroyBlock(block.getBlockPos(), block.getDirection())) {
                    mc.player.swing(InteractionHand.MAIN_HAND);
                }
                mining = true;
                return;
            }
        }
        if (mining) {
            mc.gameMode.stopDestroyBlock();
            mining = false;
        }
    }
}
