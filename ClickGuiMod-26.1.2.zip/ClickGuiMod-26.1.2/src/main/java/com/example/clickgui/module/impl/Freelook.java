package com.example.clickgui.module.impl;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.util.CameraRig;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.client.CameraType;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.phys.Vec3;

/** Melihat sekeliling tanpa memutar arah hadap pemain (otomatis ke third person). */
public class Freelook extends Module {
    private CameraType previousType;

    public Freelook() { super("Freelook", Category.MISC); }

    @Override
    protected void onEnable() {
        if (mc.player == null) return;
        CameraRig.start(this, mc.player.getEyePosition());
        previousType = mc.options.getCameraType();
        mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
    }

    @Override
    protected void onDisable() {
        CameraRig.stop(this);
        if (previousType != null) mc.options.setCameraType(previousType);
        previousType = null;
    }

    @Override
    public void onPreTick() {
        if (mc.player != null && mc.level != null && !CameraRig.valid(this)) {
            CameraRig.start(this, mc.player.getEyePosition());
        }
    }

    /** Hook per-frame: kamera menempel di mata pemain, rotasinya dari mouse. */
    @Override
    public void extract(WorldShapes shapes, float pt) {
        if (!CameraRig.valid(this)) return;
        CameraRig.pumpRotation();
        Marker c = CameraRig.camera();
        Vec3 eye = mc.player.getEyePosition(pt);
        c.setPos(eye.x, eye.y, eye.z);
        CameraRig.syncOld();
    }
}
