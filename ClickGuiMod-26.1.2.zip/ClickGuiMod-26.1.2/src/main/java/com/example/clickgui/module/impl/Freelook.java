package com.example.clickgui.module.impl;

import com.example.clickgui.ClickGuiMod;
import com.example.clickgui.mixin.MixinStatus;
import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.ModeSetting;
import com.example.clickgui.module.Module;
import net.minecraft.client.CameraType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

/**
 * Melihat sekeliling tanpa memutar arah hadap pemain (pola Freelook Glazed).
 *
 * Modul menyimpan yaw/pitch kamera sendiri. EntityMixin mengalihkan gerakan mouse ke sini,
 * CameraMixin memakai nilainya untuk rotasi kamera. Rotasi pemain tidak pernah berubah, jadi gerak,
 * paket ke server, dan arah hadap tubuh tetap seperti semula.
 * Target mining/klik kanan mengikuti arah kamera: EntityMixin membuat Minecraft memakai arah kamera
 * sebagai arah pandang pemain saat membidik, jadi blok yang disorot = blok yang digali.
 */
public class Freelook extends Module {
    /** OFF (bawaan): tekan sekali = ON, sekali lagi = OFF. ON: tahan tombol untuk melihat sekeliling. */
    private final BoolSetting hold = bool("Hold key", false);
    /** Kamera boleh menembus blok, tidak "mundur" saat menabrak dinding. */
    private final BoolSetting seeThroughWalls = bool("See through walls", false);
    private final ModeSetting view = mode("View", "Back", "Back", "Front", "First person");

    private float yaw, pitch;   // rotasi kamera
    private boolean active;
    private CameraType previousType;
    private String appliedView = "";
    private int activeTicks;
    private boolean warned;

    public Freelook() { super("Freelook", Category.MISC); }

    @Override public boolean persistent() { return false; }
    @Override public boolean holdKey() { return hold.get(); }

    public boolean seeThroughWalls() { return seeThroughWalls.get(); }
    public boolean cameraReady() { return active; }
    public float yaw() { return yaw; }
    public float pitch() { return pitch; }

    /** Dipanggil EntityMixin dengan gerakan mouse yang sudah dikali 0.15. */
    public void updateRotation(double deltaYaw, double deltaPitch) {
        yaw = Mth.wrapDegrees(yaw + (float) deltaYaw);
        pitch = Mth.clamp(pitch + (float) deltaPitch, -90.0f, 90.0f);
    }

    @Override
    public void onWorldChanged() {
        active = false; // jangan menyentuh pemain di dunia baru
        setEnabled(false);
    }

    @Override
    protected void onEnable() {
        Player p = mc.player;
        if (p == null) return;
        // Freecam dan Freelook tidak boleh aktif bersamaan
        ClickGuiMod.MODULES.freecam.setEnabled(false);

        yaw = p.getYRot();
        pitch = p.getXRot();
        previousType = mc.options.getCameraType();
        activeTicks = 0;
        warned = false;
        active = true;
        applyView();
    }

    @Override
    protected void onDisable() {
        active = false;
        if (previousType != null) mc.options.setCameraType(previousType);
        previousType = null;
        appliedView = "";
    }

    private void applyView() {
        String v = view.get();
        mc.options.setCameraType(switch (v) {
            case "Front" -> CameraType.THIRD_PERSON_FRONT;
            case "First person" -> CameraType.FIRST_PERSON;
            default -> CameraType.THIRD_PERSON_BACK;
        });
        appliedView = v;
    }

    @Override
    public void onPreTick() {
        if (!active || mc.player == null) return;
        if (!view.get().equals(appliedView)) applyView();

        // Diagnostik: beri tahu jika mixin kamera tidak terpasang
        if (!warned && ++activeTicks >= 40) {
            warned = true;
            if (!MixinStatus.cameraSetup || !MixinStatus.rotationApplied) {
                chat("[JetMonClient] Freelook: mixin kamera tidak terpasang (setup=" + MixinStatus.cameraSetup
                    + ", rotasi=" + MixinStatus.rotationApplied + ", bidik=" + MixinStatus.aimApplied
                    + "). Kirim latest.log ke pembuat mod.");
            }
        }
    }
}
