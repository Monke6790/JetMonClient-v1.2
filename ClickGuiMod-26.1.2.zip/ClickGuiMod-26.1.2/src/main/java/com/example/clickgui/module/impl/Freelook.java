package com.example.clickgui.module.impl;

import com.example.clickgui.module.BoolSetting;
import com.example.clickgui.module.Category;
import com.example.clickgui.module.ModeSetting;
import com.example.clickgui.module.Module;
import com.example.clickgui.module.util.CameraRig;
import com.example.clickgui.render.WorldShapes;
import net.minecraft.client.CameraType;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.phys.Vec3;

/** Melihat sekeliling tanpa memutar arah hadap pemain. Sudut pandang bisa dipilih lewat setting View. */
public class Freelook extends Module {
    /** OFF (bawaan): tekan sekali untuk ON, tekan lagi untuk OFF. ON: tahan tombol untuk melihat sekeliling. */
    private final BoolSetting hold = bool("Hold key", false);
    private final ModeSetting view = mode("View", "Back", "Back", "Front", "First person");

    private CameraType previousType;
    private String appliedView = "";

    public Freelook() { super("Freelook", Category.MISC); }

    @Override public boolean persistent() { return false; }
    @Override public boolean holdKey() { return hold.get(); }

    @Override public void onWorldChanged() { setEnabled(false); }

    @Override
    protected void onEnable() {
        if (mc.player == null) return;
        CameraRig.start(this, mc.player.getEyePosition());
        previousType = mc.options.getCameraType();
        applyView();
    }

    @Override
    protected void onDisable() {
        CameraRig.stop(this);
        if (previousType != null) mc.options.setCameraType(previousType);
        previousType = null;
        appliedView = "";
    }

    private void applyView() {
        String v = view.get();
        mc.options.setCameraType(switch (v) {
            case "Front" -> CameraType.THIRD_PERSON_FRONT;
            case "First person" -> CameraType.FIRST_PERSON;
            default -> CameraType.THIRD_PERSON_BACK;
        });
        appliedView = v;
    }

    @Override
    public void onPreTick() {
        if (mc.player == null || mc.level == null) return;
        if (!CameraRig.valid(this)) CameraRig.start(this, mc.player.getEyePosition());
        // Setting View diganti saat Freelook aktif
        if (!view.get().equals(appliedView)) applyView();
    }

    /** Hook per-frame: kamera menempel di mata pemain, rotasinya dari mouse. */
    @Override
    public void extract(WorldShapes shapes, float pt) {
        if (!CameraRig.valid(this)) return;
        CameraRig.pumpRotation();
        Marker c = CameraRig.camera();
        Vec3 eye = mc.player.getEyePosition(pt);
        c.setPos(eye.x, eye.y, eye.z);
        CameraRig.syncOld();
    }
}
