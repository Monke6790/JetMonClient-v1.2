package com.example.clickgui.module.util;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.network.chat.Component;

/** Membaca dan mengganti tombol KeyMapping lewat reflection. Tersimpan otomatis di options.txt. */
public final class KeyBinds {
    private KeyBinds() {}

    public static String name(KeyMapping m) {
        if (m == null) return "?";
        try {
            Object unbound = KeyMapping.class.getMethod("isUnbound").invoke(m);
            if (Boolean.TRUE.equals(unbound)) return "None";
            Object text = KeyMapping.class.getMethod("getTranslatedKeyMessage").invoke(m);
            return ((Component) text).getString();
        } catch (Throwable t) {
            return "?";
        }
    }

    /** code = GLFW key code, atau -1 untuk menghapus tombol. Return false jika gagal. */
    public static boolean bind(KeyMapping m, int code) {
        if (m == null) return false;
        try {
            Object key = InputConstants.Type.class.getMethod("getOrCreate", int.class)
                .invoke(InputConstants.Type.KEYSYM, code);
            Class<?> keyClass = Class.forName("com.mojang.blaze3d.platform.InputConstants$Key");
            KeyMapping.class.getMethod("setKey", keyClass).invoke(m, key);
            KeyMapping.class.getMethod("resetMapping").invoke(null);
            Options.class.getMethod("save").invoke(Minecraft.getInstance().options);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
