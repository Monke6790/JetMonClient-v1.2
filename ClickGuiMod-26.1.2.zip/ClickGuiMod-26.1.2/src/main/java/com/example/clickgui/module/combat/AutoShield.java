package com.example.clickgui.module.combat;

import com.example.clickgui.module.NumberSetting;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;

/** Menahan perisai saat ada musuh/pemain dalam jarak dekat. */
public class AutoShield extends CombatModule {
    private final NumberSetting range = number("Range", 3, 8, 1, 5);
    private boolean pressed;

    public AutoShield() { super("AutoShield"); }

    @Override
    protected void combatTick() {
        boolean hasShield = mc.player.getOffhandItem().is(Items.SHIELD)
            || mc.player.getMainHandItem().is(Items.SHIELD);
        boolean threat = false;
        if (hasShield) {
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e == mc.player) continue;
                if ((e instanceof Enemy || e instanceof Player) && mc.player.distanceTo(e) < range.get()) {
                    threat = true;
                    break;
                }
            }
        }
        if (threat && !pressed) {
            mc.options.keyUse.setDown(true);
            pressed = true;
        } else if (!threat && pressed) {
            mc.options.keyUse.setDown(false);
            pressed = false;
        }
    }

    @Override
    protected void onDisable() {
        if (pressed) {
            mc.options.keyUse.setDown(false);
            pressed = false;
        }
    }
}
