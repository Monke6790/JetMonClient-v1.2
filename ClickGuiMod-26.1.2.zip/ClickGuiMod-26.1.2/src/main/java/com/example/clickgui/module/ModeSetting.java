package com.example.clickgui.module;

/** Pilihan beberapa opsi; di ClickGUI di-tap untuk berganti ke opsi berikutnya. */
public class ModeSetting {
    private final String name;
    private final String[] options;
    private int index;

    public ModeSetting(String name, String def, String... options) {
        this.name = name;
        this.options = options;
        for (int i = 0; i < options.length; i++) if (options[i].equals(def)) index = i;
    }

    public String getName() { return name; }
    public String get() { return options[index]; }
    public void set(String v) {
        for (int i = 0; i < options.length; i++) if (options[i].equals(v)) index = i;
    }
    public void cycle() { index = (index + 1) % options.length; }
}
