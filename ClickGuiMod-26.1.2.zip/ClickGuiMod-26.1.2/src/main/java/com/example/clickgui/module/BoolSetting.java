package com.example.clickgui.module;

/** Pengaturan ON/OFF yang bisa di-tap di ClickGUI. */
public class BoolSetting {
    private final String name;
    private boolean value;

    public BoolSetting(String name, boolean def) {
        this.name = name;
        this.value = def;
    }

    public String getName() { return name; }
    public boolean get() { return value; }
    public void toggle() { value = !value; }
}
