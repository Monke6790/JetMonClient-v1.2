package com.example.clickgui.module.combat;

import com.example.clickgui.module.Category;
import com.example.clickgui.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.function.Predicate;

/**
 * Dasar modul combat untuk latihan.
 * Modul combat HANYA aktif di world single-player yang tidak dibuka ke LAN.
 */
public abstract class CombatModule extends Module {
    public CombatModule(String name) { super(name, Category.COMBAT); }

    public static boolean practiceWorld() {
        var server = Minecraft.getInstance().getSingleplayerServer();
        return server != null && !server.isPublished();
    }

    @Override
    protected void onEnable() {
        if (!practiceWorld() && mc.player != null) {
            mc.player.displayClientMessage(
                Component.literal("[ClickGUI] Modul combat hanya aktif di world single-player"), true);
        }
    }

    @Override
    public final void onTick() {
        if (!practiceWorld() || mc.player == null || mc.level == null
            || mc.gameMode == null || mc.screen != null) return;
        combatTick();
    }

    protected abstract void combatTick();

    /**
     * True jika item di tangan utama cocok. Kalau belum, pilih slot hotbar yang cocok
     * dan return false (aksi dilakukan di tick berikutnya, setelah server tahu slot berubah).
     */
    protected boolean holding(Predicate<ItemStack> match) {
        if (match.test(mc.player.getMainHandItem())) return true;
        Inventory inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (match.test(inv.getItem(i))) {
                inv.setSelectedSlot(i);
                return false;
            }
        }
        return false;
    }
}
